package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import database.MyDatabase;
import java.sql.*;
import java.util.Calendar;

public class MakeReservationPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<Integer> comboYearCheckIn, comboYearCheckOut;
    private JComboBox<String> comboMonthCheckIn, comboMonthCheckOut;
    private JComboBox<Integer> comboDayCheckIn, comboDayCheckOut;
    private JComboBox<String> comboRoomType;
    private JTable tableAvailableRooms;
    private JButton btnSearchRoom, btnConfirmReservation;
    private JLabel lblTotalPrice;
    private static String customerName;
    private String username;

    private int currentYear = Calendar.getInstance().get(Calendar.YEAR);
    private int currentMonth = Calendar.getInstance().get(Calendar.MONTH);
    private int currentDay = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);

    @SuppressWarnings("serial")
    public MakeReservationPage(String username) throws ClassNotFoundException {
        this.username = username;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(new BorderLayout(10, 10));
        setContentPane(contentPane);

        customerName = getCustomerNameFromUsername(username);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());
        JLabel lblWelcomeMessage = new JLabel("Welcome, " + customerName + "!", JLabel.CENTER);
        lblWelcomeMessage.setFont(new Font("Arial", Font.BOLD, 20));
        headerPanel.add(lblWelcomeMessage, BorderLayout.CENTER);
        headerPanel.setBackground(Color.WHITE);
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Details Panel
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Reservation Details"));
        detailsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Check-in and Check-out Panels
        JPanel checkInPanel = createDatePanel("Check-in Date:", true);
        JPanel checkOutPanel = createDatePanel("Check-out Date:", false);

        // Room Type Panel
        JPanel roomTypePanel = new JPanel();
        roomTypePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
        JLabel lblRoomType = new JLabel("Room Type:");
        comboRoomType = new JComboBox<>();
        loadRoomTypes();
        roomTypePanel.add(lblRoomType);
        roomTypePanel.add(comboRoomType);

        // Search Room Button
        btnSearchRoom = new JButton("Search Room");
        btnSearchRoom.addActionListener(e -> {
            try {
                loadAvailableRooms();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error loading available rooms.");
            }
        });
        roomTypePanel.add(btnSearchRoom);

        // Adding to detailsPanel
        detailsPanel.add(checkInPanel);
        detailsPanel.add(Box.createVerticalStrut(10));
        detailsPanel.add(checkOutPanel);
        detailsPanel.add(Box.createVerticalStrut(10));
        detailsPanel.add(roomTypePanel);
        contentPane.add(detailsPanel, BorderLayout.WEST);

        // Available Rooms Table
        JScrollPane scrollPaneAvailable = new JScrollPane();
        tableAvailableRooms = new JTable();
        tableAvailableRooms.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableAvailableRooms.setModel(new DefaultTableModel(new Object[]{"Room Number", "Price (RM)", "Room Type"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });
        scrollPaneAvailable.setViewportView(tableAvailableRooms);
        contentPane.add(scrollPaneAvailable, BorderLayout.CENTER);

        // Confirm Reservation Button
        btnConfirmReservation = new JButton("Confirm Reservation");
        btnConfirmReservation.addActionListener(e -> confirmReservation());
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(btnConfirmReservation);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createDatePanel(String labelText, boolean isCheckIn) {
        JPanel datePanel = new JPanel();
        datePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JLabel lblDate = new JLabel(labelText);

        JComboBox<Integer> yearCombo = new JComboBox<>();
        JComboBox<String> monthCombo = new JComboBox<>(new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"});
        JComboBox<Integer> dayCombo = new JComboBox<>();
        initializeDateSelector(yearCombo, monthCombo, dayCombo, isCheckIn);

        yearCombo.setPreferredSize(new Dimension(80, 30));
        monthCombo.setPreferredSize(new Dimension(100, 30));
        dayCombo.setPreferredSize(new Dimension(60, 30));

        datePanel.add(lblDate);
        datePanel.add(yearCombo);
        datePanel.add(monthCombo);
        datePanel.add(dayCombo);

        if (isCheckIn) {
            comboYearCheckIn = yearCombo;
            comboMonthCheckIn = monthCombo;
            comboDayCheckIn = dayCombo;
        } else {
            comboYearCheckOut = yearCombo;
            comboMonthCheckOut = monthCombo;
            comboDayCheckOut = dayCombo;
        }

        return datePanel;
    }

    private void initializeDateSelector(JComboBox<Integer> yearCombo, JComboBox<String> monthCombo, JComboBox<Integer> dayCombo, boolean isCheckIn) {
        for (int i = currentYear - 10; i <= currentYear + 10; i++) {
            yearCombo.addItem(i);
        }
        yearCombo.setSelectedItem(currentYear);

        monthCombo.addActionListener(e -> updateDaysForMonth(yearCombo, monthCombo, dayCombo));
        monthCombo.setSelectedIndex(currentMonth);
        updateDaysForMonth(yearCombo, monthCombo, dayCombo);

        if (isCheckIn) {
            dayCombo.setSelectedItem(currentDay);
        }
    }

    private void updateDaysForMonth(JComboBox<Integer> yearCombo, JComboBox<String> monthCombo, JComboBox<Integer> dayCombo) {
        Integer year = (Integer) yearCombo.getSelectedItem();
        String monthStr = (String) monthCombo.getSelectedItem();

        if (year == null || monthStr == null) {
            return;
        }

        int month = monthCombo.getSelectedIndex();
        int daysInMonth = getDaysInMonth(year, month);
        dayCombo.removeAllItems();

        for (int i = 1; i <= daysInMonth; i++) {
            dayCombo.addItem(i);
        }

        dayCombo.setSelectedItem(1);
    }

    private int getDaysInMonth(int year, int month) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 1);
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    private String getCustomerNameFromUsername(String username) throws ClassNotFoundException {
        String fullName = "Guest";
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT name FROM customer WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                fullName = rs.getString("name");
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fullName;
    }

    private void loadRoomTypes() throws ClassNotFoundException {
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT DISTINCT roomtype FROM room";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                comboRoomType.addItem(rs.getString("roomtype"));
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadAvailableRooms() throws ClassNotFoundException {
        DefaultTableModel model = (DefaultTableModel) tableAvailableRooms.getModel();
        model.setRowCount(0); // Clear the table

        Integer checkInYear = (Integer) comboYearCheckIn.getSelectedItem();
        Integer checkInDay = (Integer) comboDayCheckIn.getSelectedItem();
        Integer checkOutYear = (Integer) comboYearCheckOut.getSelectedItem();
        Integer checkOutDay = (Integer) comboDayCheckOut.getSelectedItem();
        String roomType = (String) comboRoomType.getSelectedItem();

        if (checkInYear == null || checkInDay == null || checkOutYear == null || checkOutDay == null || roomType == null) {
            return;
        }

        int checkInMonth = comboMonthCheckIn.getSelectedIndex();
        int checkOutMonth = comboMonthCheckOut.getSelectedIndex();

        Calendar checkInCal = Calendar.getInstance();
        checkInCal.set(checkInYear, checkInMonth, checkInDay);
        java.sql.Date checkInDate = new java.sql.Date(checkInCal.getTimeInMillis());

        Calendar checkOutCal = Calendar.getInstance();
        checkOutCal.set(checkOutYear, checkOutMonth, checkOutDay);
        java.sql.Date checkOutDate = new java.sql.Date(checkOutCal.getTimeInMillis());

        // Validate dates
        if (checkInDate.before(new java.sql.Date(System.currentTimeMillis()))) {
            JOptionPane.showMessageDialog(null, "Check-in date cannot be in the past.");
            return;
        }
        if (checkOutDate.before(checkInDate) || checkOutDate.equals(checkInDate)) {
            JOptionPane.showMessageDialog(null, "Check-out date must be after check-in date.");
            return;
        }

        try (Connection conn = MyDatabase.doConnection()) {
            // Query to find available rooms
            String sql = "SELECT r.roomnumber, r.roomprice " +
                         "FROM room r " +
                         "WHERE r.roomtype = ? AND r.status = 'available' " +
                         "AND r.roomnumber NOT IN (" +
                         "    SELECT res.roomnumber " +
                         "    FROM reservation res " +
                         "    WHERE res.check_in_date <= ? AND res.check_out_date >= ? " +
                         "    AND res.status != 'cancelled'" + // Exclude rooms with active reservations
                         ")";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, roomType);
            pstmt.setDate(2, checkOutDate);
            pstmt.setDate(3, checkInDate);
            ResultSet rs = pstmt.executeQuery();

            // Add available rooms to the table
            while (rs.next()) {
                Object[] row = {rs.getString("roomnumber"), rs.getDouble("roomprice"), roomType};
                model.addRow(row);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading available rooms.");
        }
    }

    private void confirmReservation() {
        int selectedRow = tableAvailableRooms.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a room to book.");
            return;
        }

        String roomNumber = (String) tableAvailableRooms.getValueAt(selectedRow, 0); // Ensure roomNumber is a String
        double price = (Double) tableAvailableRooms.getValueAt(selectedRow, 1);

        Integer checkInYear = (Integer) comboYearCheckIn.getSelectedItem();
        Integer checkInMonth = comboMonthCheckIn.getSelectedIndex();
        Integer checkInDay = (Integer) comboDayCheckIn.getSelectedItem();
        Integer checkOutYear = (Integer) comboYearCheckOut.getSelectedItem();
        Integer checkOutMonth = comboMonthCheckOut.getSelectedIndex();
        Integer checkOutDay = (Integer) comboDayCheckOut.getSelectedItem();

        Calendar checkInCal = Calendar.getInstance();
        checkInCal.set(checkInYear, checkInMonth, checkInDay);
        java.sql.Date checkInDate = new java.sql.Date(checkInCal.getTimeInMillis());

        Calendar checkOutCal = Calendar.getInstance();
        checkOutCal.set(checkOutYear, checkOutMonth, checkOutDay);
        java.sql.Date checkOutDate = new java.sql.Date(checkOutCal.getTimeInMillis());

        // Check if the room is still available
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT COUNT(*) AS count FROM reservation " +
                         "WHERE roomnumber = ? AND check_in_date <= ? AND check_out_date >= ? AND status != 'cancelled'";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, roomNumber);
            pstmt.setDate(2, checkOutDate);
            pstmt.setDate(3, checkInDate);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next() && rs.getInt("count") > 0) {
                JOptionPane.showMessageDialog(null, "This room is no longer available. Please select another room.");
                return;
            }
            rs.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error confirming reservation.");
            return;
        }

        // Update room status to "booked" if the reservation is for today
        if (checkInDate.equals(new java.sql.Date(System.currentTimeMillis()))) {
            try (Connection conn = MyDatabase.doConnection()) {
                String sql = "UPDATE room SET status = 'booked' WHERE roomnumber = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, roomNumber); // Pass roomNumber as a String
                pstmt.executeUpdate();
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating room status.");
                return;
            }
        }

        // Save reservation
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "INSERT INTO reservation (customer_id, reservation_date, check_in_date, check_out_date, roomnumber, status) " +
                         "VALUES ((SELECT customer_id FROM customer WHERE username = ?), CURDATE(), ?, ?, ?, 'active')";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setDate(2, checkInDate);
            pstmt.setDate(3, checkOutDate);
            pstmt.setString(4, roomNumber); // Pass roomNumber as a String
            pstmt.executeUpdate();

            // Show success message
            JOptionPane.showMessageDialog(null, "Reservation confirmed!");

            // Navigate to PaymentPage
            PaymentPage paymentPage = new PaymentPage(username, checkInDate.toString(), checkOutDate.toString(), price);
            paymentPage.setVisible(true);
            dispose(); // Close the current window
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error confirming reservation.");
        }
    }
}