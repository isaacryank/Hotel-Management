package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import database.MyDatabase;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.io.File;
import java.io.IOException;

public class ViewPaymentsPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String username;
    private JTable paymentsTable;
    private DefaultTableModel tableModel;

    public ViewPaymentsPage(String username) {
        this.username = username;

        // Change the default close operation to DISPOSE_ON_CLOSE
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Only closes this window
        setBounds(100, 100, 800, 400); // Increased size to accommodate the table
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        // Table setup
        tableModel = new DefaultTableModel(new Object[]{"Payment ID", "Payment Date", "Payment Amount", "Payment Method", "Payment Status", "Print Receipt"}, 0);
        paymentsTable = new JTable(tableModel);
        paymentsTable.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(paymentsTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Load payments
        loadPayments();

        // Add a Print Receipt button for each row
        addPrintButton();

        // Add an Exit button at the bottom
        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close only this window
            }
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnExit);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadPayments() {
        // Clear old rows
        tableModel.setRowCount(0);

        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT p.payment_id, p.payment_date, p.payment_amount, p.payment_method, " +
                         "p.refund_status, c.customer_id, r.check_in_date, r.check_out_date " +
                         "FROM payment p " +
                         "JOIN customer c ON p.customer_id = c.customer_id " +
                         "JOIN reservation r ON p.reservation_id = r.reservation_id " +
                         "WHERE c.username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int paymentId = rs.getInt("payment_id");
                String paymentDate = rs.getString("payment_date");
                double paymentAmount = rs.getDouble("payment_amount");
                String paymentMethod = rs.getString("payment_method");
                String refundStatus = rs.getString("refund_status"); // Fetch refund status

                // Add row to the table with Payment Status
                tableModel.addRow(new Object[]{paymentId, paymentDate, paymentAmount, paymentMethod, refundStatus, "Print Receipt"});
                System.out.println("Row added: PaymentID=" + paymentId + ", RefundStatus=" + refundStatus);
            }
            rs.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching payments.");
        }

        // Refresh table
        tableModel.fireTableDataChanged();
    }

    private void addPrintButton() {
        // Add a button column to the table
        paymentsTable.getColumn("Print Receipt").setCellRenderer(new ButtonRenderer());
        paymentsTable.getColumn("Print Receipt").setCellEditor(new ButtonEditor(new JCheckBox()));
    }

    // Button renderer for the table
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    // Button editor for the table
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean isPushed;
        private int selectedRow;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            isPushed = true;
            selectedRow = row;
            return button;
        }

        public Object getCellEditorValue() {
            if (isPushed) {
                // Handle print receipt action
                int paymentId = (int) tableModel.getValueAt(selectedRow, 0);
                String paymentDate = (String) tableModel.getValueAt(selectedRow, 1);
                double paymentAmount = (double) tableModel.getValueAt(selectedRow, 2);
                String paymentMethod = (String) tableModel.getValueAt(selectedRow, 3);
                String paymentStatus = (String) tableModel.getValueAt(selectedRow, 4); // Fetch payment status

                // Fetch additional data from the database
                try (Connection conn = MyDatabase.doConnection()) {
                    String sql = "SELECT c.customer_id, r.check_in_date, r.check_out_date " +
                                 "FROM payment p " +
                                 "JOIN customer c ON p.customer_id = c.customer_id " +
                                 "JOIN reservation r ON p.reservation_id = r.reservation_id " +
                                 "WHERE p.payment_id = ?";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, paymentId);
                    ResultSet rs = pstmt.executeQuery();

                    if (rs.next()) {
                        int customerID = rs.getInt("customer_id");
                        String checkIn = rs.getString("check_in_date"); // Corrected column name
                        String checkOut = rs.getString("check_out_date"); // Corrected column name

                        // Generate PDF receipt with additional data
                        generateReceipt(paymentId, paymentDate, paymentAmount, paymentMethod, customerID, checkIn, checkOut, paymentStatus);
                    }
                    rs.close();
                } catch (ClassNotFoundException | SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(ViewPaymentsPage.this, "Error fetching additional data.");
                }
            }
            isPushed = false;
            return label;
        }

        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }

    private void generateReceipt(int paymentId, String paymentDate, double paymentAmount, String paymentMethod,
            int customerID, String checkIn, String checkOut, String paymentStatus) {
        String fileName = "Booking_Confirmation_" + paymentId + ".pdf";
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                contentStream.setNonStrokingColor(0, 0, 0); // Black text color

                // Hotel Logo (Centered)
                PDImageXObject logo = PDImageXObject.createFromFile(
                    "C:\\Users\\user\\Desktop\\Study Box\\Sem 3\\Kessigan OOP\\PalmHotelLogo.jpg", document
                );
                float logoWidth = logo.getWidth();
                float logoHeight = logo.getHeight();
                float xPosition = (page.getMediaBox().getWidth() - logoWidth) / 2; // Center horizontally
                float yPosition = 750f; // Position from top

                // Draw the logo
                contentStream.drawImage(logo, xPosition, yPosition, logoWidth, logoHeight);

                // Header Title: Palm Garden Hotel and Tagline
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 18);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, yPosition - 40); // Move a bit below the logo
                contentStream.showText("Palm Garden Hotel");
                contentStream.endText();
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, yPosition - 60);
                contentStream.showText("Experience luxury and comfort like never before");
                contentStream.endText();

                // Guest Information Section
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 14);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, yPosition - 100);
                contentStream.showText("Guest Information");
                contentStream.endText();
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, yPosition - 120);
                contentStream.showText("Customer ID: " + customerID);
                contentStream.endText();

                // Reservation Details Section
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 14);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, yPosition - 160);
                contentStream.showText("Reservation Details");
                contentStream.endText();
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, yPosition - 180);
                contentStream.showText("Check-In Date: " + checkIn);
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Check-Out Date: " + checkOut);
                contentStream.endText();

                // Payment Information Section
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 14);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, yPosition - 240);
                contentStream.showText("Payment Information");
                contentStream.endText();
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, yPosition - 260);
                contentStream.showText("Payment Date: " + paymentDate);
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Payment Method: " + paymentMethod);
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Payment Amount: RM " + paymentAmount); // Add payment amount
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Payment Status: " + paymentStatus); // Add payment status
                contentStream.endText();

                // Footer
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 10);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, 100); // Footer position
                contentStream.showText("Thank you for choosing Palm Garden Hotel. We look forward to hosting you!");
                contentStream.endText();
                contentStream.beginText();
                contentStream.newLineAtOffset(100, 80);
                contentStream.showText("Contact us: +1 637 555 111 | info@palmgardenhotel.com");
                contentStream.endText();
            }

            document.save(fileName);
            JOptionPane.showMessageDialog(this, "Booking Confirmation generated: " + new File(fileName).getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error generating Booking Confirmation.");
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ViewPaymentsPage frame = new ViewPaymentsPage("exampleUsername"); // Replace with actual username
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}