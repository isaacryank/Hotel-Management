package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import database.MyDatabase;

public class ManageRoomsPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable roomTable;
    private DefaultTableModel model;
    private JButton btnPreviousPage, btnNextPage, btnAdd, btnRemove, btnUpdate;
    private int currentPage = 1;
    private int rowsPerPage = 10; // Display 10 rows per page
    private List<Object[]> roomData; // Holds all rows of room data
    
    public int getCurrentPage() {
        return currentPage;
    }

    /**
     * Create the frame.
     */
    public ManageRoomsPage() throws ClassNotFoundException {
        // Set up the JFrame
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(new BorderLayout(10, 10));
        setContentPane(contentPane);

        // Table column headers
        String[] columnNames = {"Room ID", "Room Number", "Room Type", "Room Price", "Status"};
        model = new DefaultTableModel(columnNames, 0);

        // JTable for displaying room details
        roomTable = new JTable(model);
        roomTable.setRowHeight(30);
        roomTable.setFont(new Font("Arial", Font.PLAIN, 14));
        roomTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        roomTable.setEnabled(false); // Make the table non-editable

        JScrollPane scrollPane = new JScrollPane(roomTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Fetch all room data
        roomData = fetchAllRooms();

        // Initialize Buttons
        initializeButtons();

        // Load the first page
        loadPage(currentPage);

        // Button panel at the bottom
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(btnPreviousPage);
        buttonPanel.add(btnNextPage);
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnRemove);
        buttonPanel.add(btnUpdate);

        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Initialize all buttons and add their event listeners.
     */
    private void initializeButtons() {
        // Pagination buttons
        btnPreviousPage = new JButton("Previous Page");
        btnPreviousPage.setEnabled(false); // Disabled by default since we start on the first page
        btnPreviousPage.addActionListener(e -> {
            if (currentPage > 1) {
                currentPage--;
                loadPage(currentPage);
            }
        });

        btnNextPage = new JButton("Next Page");
        btnNextPage.addActionListener(e -> {
            if ((currentPage * rowsPerPage) < roomData.size()) {
                currentPage++;
                loadPage(currentPage);
            }
        });

        // Add, Remove, and Update Room buttons
        btnAdd = new JButton("Add Room");
        btnAdd.addActionListener(e -> {
            AddRoom addRoomFrame = new AddRoom(this);
            addRoomFrame.setVisible(true);
        });

        btnRemove = new JButton("Remove Room");
        btnRemove.addActionListener(e -> {
            RemoveRoom removeRoomPage = new RemoveRoom(this); // Passing 'this' to the RemoveRoom constructor
            removeRoomPage.setVisible(true);  // Make the RemoveRoom window visible
        });

        btnUpdate = new JButton("Update Room");
        btnUpdate.addActionListener(e -> {
            UpdateRoom updateRoomFrame = new UpdateRoom(this);
            updateRoomFrame.setVisible(true);
        });
    }

    /**
     * Fetch all room data from the database.
     */
    private List<Object[]> fetchAllRooms() throws ClassNotFoundException {
        List<Object[]> data = new ArrayList<>();
        String sql = "SELECT room_id, roomnumber, roomtype, roomprice, status FROM room";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                // Add each room's details to the list
                data.add(new Object[] {
                        rs.getString("room_id"),
                        rs.getString("roomnumber"),
                        rs.getString("roomtype"),
                        rs.getDouble("roomprice"),
                        rs.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data;
    }

    /**
     * Load the specified page into the table.
     */
    public void loadPage(int page) {
        // Refresh the room data from the database
        try {
            roomData = fetchAllRooms();  // Fetch updated room data
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Clear the current table data
        model.setRowCount(0);

        // Calculate the start and end indices for the rows to display
        int startIndex = (page - 1) * rowsPerPage;
        int endIndex = Math.min(startIndex + rowsPerPage, roomData.size());

        // Add rows for the current page
        for (int i = startIndex; i < endIndex; i++) {
            model.addRow(roomData.get(i));
        }

        // Update button states
        btnPreviousPage.setEnabled(page > 1);
        btnNextPage.setEnabled(endIndex < roomData.size());
    }

    // Main method to launch the page
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ManageRoomsPage frame = new ManageRoomsPage();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
