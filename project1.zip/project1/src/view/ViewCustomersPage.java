package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import database.MyDatabase;

public class ViewCustomersPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable customerTable;
    private JButton btnExit;

    /**
     * Create the frame.
     */
    public ViewCustomersPage() throws ClassNotFoundException {
        // Set the default close operation
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 1000, 600); // Adjust window size
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(new BorderLayout(10, 10));

        setContentPane(contentPane);

        // Column names for the table
        String[] columnNames = {"Customer ID", "Name", "Username", "Email", "Phone Number", "Address", "Membership ID", "Loyalty Points"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        // JTable to display all customers
        customerTable = new JTable(model);
        customerTable.setRowHeight(30);
        customerTable.setFont(new Font("Arial", Font.PLAIN, 14));
        customerTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        customerTable.setEnabled(false); // Make the table non-editable

        JScrollPane scrollPane = new JScrollPane(customerTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Fetch all customer data and populate the table
        fetchAllCustomers(model);

        // Exit button to close the page
        btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.BOLD, 14));
        btnExit.setBackground(new Color(200, 50, 50)); // Red color for exit button
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        btnExit.addActionListener(e -> dispose()); // Close only this window

        // Add the exit button at the bottom
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(btnExit);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Fetch all customers from the database and populate the table.
     */
    private void fetchAllCustomers(DefaultTableModel model) throws ClassNotFoundException {
        // Query to fetch customer data with loyalty points from the membership table
        String sql = "SELECT c.customer_id, c.name, c.username, c.email, c.phonenumber, c.address, " +
                     "c.member_id, m.loyalty_points " +
                     "FROM customer c " +
                     "LEFT JOIN membership m ON c.member_id = m.member_id";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                // Extract data for each customer
                int customerId = rs.getInt("customer_id"); // Assuming "customer_id" is the primary key
                String name = rs.getString("name");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String phone = rs.getString("phonenumber");
                String address = rs.getString("address");
                String memberId = rs.getString("member_id");
                int loyaltyPoints = rs.getInt("loyalty_points");

                // Add data to the table model
                model.addRow(new Object[]{
                    customerId,
                    name,
                    username,
                    email,
                    phone,
                    address,
                    (memberId != null ? memberId : "Not a member"), // Show "Not a member" if member_id is null
                    (memberId != null ? loyaltyPoints : "N/A")     // Show "N/A" if not a member
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addRow(new Object[]{"Error", "Failed to fetch customer data."});
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ViewCustomersPage frame = new ViewCustomersPage();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
