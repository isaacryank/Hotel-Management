package view;

import javax.swing.*;
import database.MyDatabase;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;

public class UpdateRoom extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtRoomNumber, txtRoomPrice;
    private JComboBox<String> cmbRoomId, cmbRoomType, cmbRoomStatus;
    private JButton btnUpdate, btnCancel;
    
    private ManageRoomsPage manageRoomsPage;  // Store reference to ManageRoomsPage

    // Variables to hold room details
    private String selectedRoomId = "";

    public UpdateRoom(ManageRoomsPage manageRoomsPage) {
        this.manageRoomsPage = manageRoomsPage; // Store the reference to the ManageRoomsPage

        // Set up the JFrame
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 400, 350);  // Adjusted height for the new dropdown
        contentPane = new JPanel();
        contentPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding around content
        contentPane.setLayout(new GridBagLayout());  // Using GridBagLayout for better organization
        setContentPane(contentPane);

        // Create GridBagConstraints to control the positioning
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);  // Space between components

        // Room ID label and combo box
        JLabel lblRoomId = new JLabel("Select Room ID");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        contentPane.add(lblRoomId, gbc);

        // Room IDs - Fetch these dynamically from the database
        String[] roomIds = fetchRoomIds();  // This method will fetch room IDs from the database
        cmbRoomId = new JComboBox<>(roomIds);
        cmbRoomId.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectedRoomId = (String) cmbRoomId.getSelectedItem();
                if (selectedRoomId != null && !selectedRoomId.isEmpty()) {
                    loadRoomDetails(selectedRoomId);
                }
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        contentPane.add(cmbRoomId, gbc);

        // Room Number label and text field
        JLabel lblRoomNumber = new JLabel("Room Number");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        contentPane.add(lblRoomNumber, gbc);

        txtRoomNumber = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        contentPane.add(txtRoomNumber, gbc);

        // Room Type label and combo box
        JLabel lblRoomType = new JLabel("Room Type");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        contentPane.add(lblRoomType, gbc);

        String[] roomTypes = { "Single", "Double", "Suite" };
        cmbRoomType = new JComboBox<>(roomTypes);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        contentPane.add(cmbRoomType, gbc);

        // Room Price label and text field
        JLabel lblRoomPrice = new JLabel("Room Price");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        contentPane.add(lblRoomPrice, gbc);

        txtRoomPrice = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        contentPane.add(txtRoomPrice, gbc);

        // Room Status label and combo box
        JLabel lblRoomStatus = new JLabel("Room Status");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        contentPane.add(lblRoomStatus, gbc);

        String[] statusOptions = { "Available", "Not Available" };
        cmbRoomStatus = new JComboBox<>(statusOptions);
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        contentPane.add(cmbRoomStatus, gbc);

        // Update Button
        btnUpdate = new JButton("Update Room");
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        contentPane.add(btnUpdate, gbc);

        // Cancel Button
        btnCancel = new JButton("Cancel");
        gbc.gridx = 2;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        contentPane.add(btnCancel, gbc);

        // Button Action Listeners
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Handle Update Room logic here
                String roomNumber = txtRoomNumber.getText().trim();
                String roomType = (String) cmbRoomType.getSelectedItem();
                String roomPrice = txtRoomPrice.getText().trim();
                String roomStatus = (String) cmbRoomStatus.getSelectedItem();  // Get selected room status

                // Validate input fields
                if (roomNumber.isEmpty() || roomType.isEmpty() || roomPrice.isEmpty()) {
                    JOptionPane.showMessageDialog(UpdateRoom.this, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                    // Re-populate the fields with the selected room details
                    loadRoomDetails(selectedRoomId); // Refresh data in text fields
                    return;
                }

                // Validate Room Price - it must be greater than 0
                double price = 0;
                try {
                    price = Double.parseDouble(roomPrice);
                    if (price <= 0) {
                        JOptionPane.showMessageDialog(UpdateRoom.this, "Room price must be greater than 0", "Error", JOptionPane.ERROR_MESSAGE);
                        // Re-populate the fields with the selected room details
                        loadRoomDetails(selectedRoomId); // Refresh data in text fields
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(UpdateRoom.this, "Invalid price format. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                    // Re-populate the fields with the selected room details
                    loadRoomDetails(selectedRoomId); // Refresh data in text fields
                    return;
                }

                // Perform the update action
                updateRoomDetails(selectedRoomId, roomNumber, roomType, price, roomStatus);
                JOptionPane.showMessageDialog(UpdateRoom.this, "Room details updated successfully!");

                // Refresh the room IDs list in the combo box
                refreshRoomIdsList();

                // Update ManageRoomsPage table
                manageRoomsPage.loadPage(manageRoomsPage.getCurrentPage());

                // Optionally, select the updated room in the combo box
                cmbRoomId.setSelectedItem(selectedRoomId);  // Keep the current selected room ID
            }
        });

        // Cancel Button Action
        btnCancel.addActionListener(e -> dispose()); // Close the window on cancel
    }

    private void refreshRoomIdsList() {
        // Fetch the updated room IDs from the database and update the combo box
        String[] roomIds = fetchRoomIds();
        cmbRoomId.removeAllItems();  // Clear the current list
        for (String roomId : roomIds) {
            cmbRoomId.addItem(roomId);  // Add each room ID back into the combo box
        }
    }

    private String[] fetchRoomIds() {
        ArrayList<String> roomIdsList = new ArrayList<>();
        String sql = "SELECT room_id FROM room";  // SQL query to fetch all room IDs

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                roomIdsList.add(rs.getString("room_id"));  // Add room ID to the list
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching room IDs", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }

        return roomIdsList.toArray(new String[0]);
    }

    private void loadRoomDetails(String roomId) {
        String sql = "SELECT roomnumber, roomtype, roomprice, status FROM room WHERE room_id = ?";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, roomId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Fill the text fields with the data
                txtRoomNumber.setText(rs.getString("roomnumber"));
                
                // Set room type in combo box
                String roomType = rs.getString("roomtype");
                for (int i = 0; i < cmbRoomType.getItemCount(); i++) {
                    if (cmbRoomType.getItemAt(i).equals(roomType)) {
                        cmbRoomType.setSelectedIndex(i);
                        break;
                    }
                }

                txtRoomPrice.setText(String.valueOf(rs.getDouble("roomprice")));
                
                // Set room status in combo box
                String roomStatus = rs.getString("status");
                cmbRoomStatus.setSelectedItem(roomStatus);  // Select the current status
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(UpdateRoom.this, "Error loading room details", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }
    }

    private void updateRoomDetails(String roomId, String roomNumber, String roomType, double roomPrice, String roomStatus) {
        String sql = "UPDATE room SET roomnumber = ?, roomtype = ?, roomprice = ?, status = ? WHERE room_id = ?";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, roomNumber);
            pstmt.setString(2, roomType);
            pstmt.setDouble(3, roomPrice);
            pstmt.setString(4, roomStatus);  // Update room status
            pstmt.setString(5, roomId);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(UpdateRoom.this, "Error updating room details", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ManageRoomsPage manageRoomsPage = new ManageRoomsPage(); // Assuming this is a valid constructor
                UpdateRoom frame = new UpdateRoom(manageRoomsPage);
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
