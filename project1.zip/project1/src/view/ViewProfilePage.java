package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import database.MyDatabase;

public class ViewProfilePage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable profileTable;
    private JButton btnUpdate;
    private JButton btnExit;

    /**
     * Create the frame.
     * @throws ClassNotFoundException 
     */
    public ViewProfilePage(String username) throws ClassNotFoundException {
        // Set the default close operation to DISPOSE_ON_CLOSE
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Only closes this window
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(new BorderLayout(10, 10));

        setContentPane(contentPane);

        // Fetch and display customer profile information
        String[] columnNames = {"Field", "Value"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        profileTable = new JTable(model);
        profileTable.setRowHeight(30);
        profileTable.setFont(new Font("Arial", Font.PLAIN, 14));
        profileTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        profileTable.setEnabled(false); // Make the table non-editable

        JScrollPane scrollPane = new JScrollPane(profileTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Fetch profile data and populate the table
        fetchCustomerProfile(username, model);

        // Button to go to the update page
        btnUpdate = new JButton("Update Profile");
        btnUpdate.setFont(new Font("Arial", Font.BOLD, 14));
        btnUpdate.setBackground(new Color(59, 89, 182));
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFocusPainted(false);
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the update page when the "Update Profile" button is clicked
                UpdateProfilePage updateProfilePage = null;
                try {
                    updateProfilePage = new UpdateProfilePage(username);
                } catch (ClassNotFoundException e1) {
                    e1.printStackTrace();
                }
                updateProfilePage.setVisible(true);
                dispose();  // Close the current frame
            }
        });

        // Exit button to close only this window
        btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.BOLD, 14));
        btnExit.setBackground(new Color(200, 50, 50)); // Red color for exit button
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close only this window
            }
        });

        // Panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Add spacing between buttons
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnExit);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Fetch the customer's profile information from the database and populate the table.
     * @throws ClassNotFoundException 
     */
    private void fetchCustomerProfile(String username, DefaultTableModel model) throws ClassNotFoundException {
        String sql = "SELECT * FROM customer WHERE username = ?";
        
        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                // Fetch all customer details
                String name = rs.getString("name");
                String password = rs.getString("c_password");
                String email = rs.getString("email");
                String phone = rs.getString("phonenumber");
                String address = rs.getString("address");
                String memberId = rs.getString("member_id");

                // Add customer details to the table
                model.addRow(new Object[]{"Name", name});
                model.addRow(new Object[]{"Username", username});
                model.addRow(new Object[]{"Password", password});
                model.addRow(new Object[]{"Email", email});
                model.addRow(new Object[]{"Phone Number", phone});
                model.addRow(new Object[]{"Address", address});
                model.addRow(new Object[]{"Membership ID", (memberId != null ? memberId : "Not a member yet")});

                // Fetch loyalty points from the membership table if member_id is not null
                if (memberId != null) {
                    int loyaltyPoints = fetchLoyaltyPoints(memberId);
                    model.addRow(new Object[]{"Loyalty Points", loyaltyPoints});
                } else {
                    model.addRow(new Object[]{"Loyalty Points", "Not a member yet"});
                }
            } else {
                model.addRow(new Object[]{"Error", "Customer not found."});
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            model.addRow(new Object[]{"Error", "Failed to fetch profile data."});
        }
    }

    /**
     * Fetch loyalty points from the membership table using member_id.
     */
    private int fetchLoyaltyPoints(String memberId) throws ClassNotFoundException {
        int loyaltyPoints = 0;
        String sql = "SELECT loyalty_points FROM membership WHERE member_id = ?";
        
        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, memberId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                loyaltyPoints = rs.getInt("loyalty_points");
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return loyaltyPoints;
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ViewProfilePage frame = new ViewProfilePage("exampleUsername"); // Pass test username for testing
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}