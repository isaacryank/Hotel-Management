package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import database.MyDatabase;

public class StaffViewReservationsPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable reservationTable;
    private DefaultTableModel model;
    private JButton btnBack;

    public StaffViewReservationsPage() throws ClassNotFoundException {
        // Set up the JFrame
        setTitle("View Reservations");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 1000, 600); // Increased the size for a better view
        contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout(10, 10));
        setContentPane(contentPane);

        // Add a header label
        JLabel lblHeader = new JLabel("RESERVATIONS", SwingConstants.CENTER);
        lblHeader.setFont(new Font("Arial", Font.BOLD, 24)); // Large font for the header
        lblHeader.setForeground(new Color(0, 0, 0));
        contentPane.add(lblHeader, BorderLayout.NORTH);

        // Table column headers
        String[] columnNames = {"Reservation ID", "Customer ID", "Customer Name", "Payment ID", "Reservation Date", 
                                "Room Number", "Check-in Date", "Check-out Date", "Status"};

        model = new DefaultTableModel(columnNames, 0);

        // JTable for displaying reservation details
        reservationTable = new JTable(model);
        reservationTable.setRowHeight(30);
        reservationTable.setFont(new Font("Arial", Font.PLAIN, 14));
        reservationTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        reservationTable.setEnabled(false); // Make the table non-editable

        // Add custom cell rendering for row background color based on status
        reservationTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                // Check the status in the last column (status is in index 8)
                String status = (String) table.getValueAt(row, 8);
                if ("Cancelled".equalsIgnoreCase(status)) {
                    cell.setBackground(new Color(255, 204, 204)); // Light red for cancelled status
                } else if ("Active".equalsIgnoreCase(status)) {
                    cell.setBackground(new Color(204, 255, 204)); // Light green for active status
                } else {
                    cell.setBackground(Color.WHITE); // White for other statuses
                }
                return cell;
            }
        });

        JScrollPane scrollPane = new JScrollPane(reservationTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Load reservation data
        loadReservations();

        // Button panel at the bottom
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        btnBack = new JButton("Back");
        btnBack.addActionListener(e -> dispose()); // Close the window on back
        buttonPanel.add(btnBack);

        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    // Method to load all reservation data
    private void loadReservations() {
        String sql = "SELECT r.reservation_id, r.customer_id, c.name, r.payment_id, r.reservation_date, r.roomnumber, " +
                     "r.check_in_date, r.check_out_date, r.status " +
                     "FROM reservation r " +
                     "JOIN customer c ON r.customer_id = c.customer_id " +
                     "JOIN payment p ON r.payment_id = p.payment_id";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            // Clear existing rows
            model.setRowCount(0);

            // Add reservation data rows to the table
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("reservation_id"),
                    rs.getString("customer_id"),
                    rs.getString("name"), // Displaying name instead of customer_name
                    rs.getString("payment_id"),
                    rs.getDate("reservation_date"),
                    rs.getString("roomnumber"),
                    rs.getDate("check_in_date"),
                    rs.getDate("check_out_date"),
                    rs.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching reservation data", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }
    }

    // Main method to launch the page
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                StaffViewReservationsPage frame = new StaffViewReservationsPage();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
