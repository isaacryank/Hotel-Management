package view;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import database.MyDatabase;

public class StaffProfilePage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblStaffId, lblName, lblUsername, lblEmail, lblPhoneNumber, lblAddress;
    private JButton btnBack;

    // Constructor takes staff_id to fetch the specific staff's details
    public StaffProfilePage(int staffId) {
        // Set up the JFrame
        setTitle("Staff Profile");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 400); // Adjust the size as needed
        contentPane = new JPanel();
        contentPane.setLayout(new GridLayout(7, 2, 10, 10));
        setContentPane(contentPane);

        // Add header label
        JLabel lblHeader = new JLabel("Staff Profile", SwingConstants.CENTER);
        lblHeader.setFont(new Font("Arial", Font.BOLD, 24));
        contentPane.add(lblHeader);

        // Initialize labels for staff details
        lblStaffId = new JLabel("Staff ID:");
        lblName = new JLabel("Name:");
        lblUsername = new JLabel("Username:");
        lblEmail = new JLabel("Email:");
        lblPhoneNumber = new JLabel("Phone Number:");
        lblAddress = new JLabel("Address:");

        // Add labels to the grid layout
        contentPane.add(lblStaffId);
        contentPane.add(new JLabel()); // Placeholder for staff ID (we'll fill it dynamically)
        contentPane.add(lblName);
        contentPane.add(new JLabel()); // Placeholder for name
        contentPane.add(lblUsername);
        contentPane.add(new JLabel()); // Placeholder for username
        contentPane.add(lblEmail);
        contentPane.add(new JLabel()); // Placeholder for email
        contentPane.add(lblPhoneNumber);
        contentPane.add(new JLabel()); // Placeholder for phone number
        contentPane.add(lblAddress);
        contentPane.add(new JLabel()); // Placeholder for address

        // Load staff data from the database
        loadStaffData(staffId);

        // Button to go back to the main page
        btnBack = new JButton("Back");
        btnBack.addActionListener(e -> dispose()); // Close the window on back
        contentPane.add(btnBack);
    }

    // Method to load staff data
    private void loadStaffData(int staffId) {
        String sql = "SELECT staff_id, name, username, email, phonenumber, address FROM staff WHERE staff_id = ?";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, staffId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Display staff data in the labels
                lblStaffId.setText("Staff ID: " + rs.getInt("staff_id"));
                lblName.setText("Name: " + rs.getString("name"));
                lblUsername.setText("Username: " + rs.getString("username"));
                lblEmail.setText("Email: " + rs.getString("email"));
                lblPhoneNumber.setText("Phone Number: " + rs.getString("phonenumber"));
                lblAddress.setText("Address: " + rs.getString("address"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading staff data", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    }

    // Main method to launch the page
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                // Pass a sample staff_id for testing
                StaffProfilePage frame = new StaffProfilePage(1);
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
