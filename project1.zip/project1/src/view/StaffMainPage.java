package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;

public class StaffMainPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private final JLabel lblStaffMenu = new JLabel("                Staff Main Menu");
    private int staffId; // Variable to hold the staffId

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    // Example: Passing a dummy staffId for testing purposes
                    StaffMainPage frame = new StaffMainPage(1); 
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame with staffId parameter.
     */
    public StaffMainPage(int staffId) {
        this.staffId = staffId; // Assign the staffId to the class variable

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(192, 192, 192));
        contentPane.setBorder(new EmptyBorder(20, 15, 20, 15));

        setContentPane(contentPane);
        contentPane.setLayout(new GridLayout(6, 1, 0, 3));
        lblStaffMenu.setFont(new Font("Tahoma", Font.PLAIN, 24));
        contentPane.add(lblStaffMenu);

        // Add View Customers Button
        JButton btnViewCustomers = new JButton("View Customers");
        btnViewCustomers.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    ViewCustomersPage viewCustomersPage = new ViewCustomersPage();
                    viewCustomersPage.setVisible(true);
                } catch (ClassNotFoundException e1) {
                    e1.printStackTrace();
                }
            }
        });
        contentPane.add(btnViewCustomers);

        // Add Manage Rooms Button
        JButton btnManageRooms = new JButton("Manage Rooms");
        btnManageRooms.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    ManageRoomsPage manageRoomsPage = new ManageRoomsPage();
                    manageRoomsPage.setVisible(true);
                } catch (ClassNotFoundException e1) {
                    e1.printStackTrace();
                }
            }
        });
        contentPane.add(btnManageRooms);

        // Add View Reservations Button
        JButton btnStaffViewReservationsPage = new JButton("View Reservations");
        btnStaffViewReservationsPage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    StaffViewReservationsPage viewReservationsPage = new StaffViewReservationsPage();
                    viewReservationsPage.setVisible(true);
                } catch (ClassNotFoundException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(StaffMainPage.this, "Error opening reservations page", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        contentPane.add(btnStaffViewReservationsPage);

        // Add View Payments Button
        JButton btnStaffViewPaymentsPage = new JButton("View Payment");
        btnStaffViewPaymentsPage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StaffViewPaymentsPage frame = new StaffViewPaymentsPage();
                frame.setVisible(true);
            }
        });
        contentPane.add(btnStaffViewPaymentsPage);

        // Add Profile Button
        JButton btnStaffProfilePage = new JButton("Your Profile");
        btnStaffProfilePage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Redirect to StaffProfilePage, passing the staffId
                StaffProfilePage staffProfilePage = new StaffProfilePage(staffId);
                staffProfilePage.setVisible(true);
            }
        });
        contentPane.add(btnStaffProfilePage);
    }
}
