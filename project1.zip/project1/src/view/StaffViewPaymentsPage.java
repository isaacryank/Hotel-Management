package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import database.MyDatabase;

public class StaffViewPaymentsPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable paymentsTable;
    private DefaultTableModel tableModel;

    public StaffViewPaymentsPage() {
        // Change the default close operation to DISPOSE_ON_CLOSE
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 800, 400); // Increased size to accommodate the table
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        // Add header label at the top with bold text "PAYMENTS"
        JLabel headerLabel = new JLabel("PAYMENTS", SwingConstants.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setPreferredSize(new Dimension(getWidth(), 40)); // Set size for the header
        contentPane.add(headerLabel, BorderLayout.NORTH);

        // Table setup
        tableModel = new DefaultTableModel(new Object[]{"Payment ID", "Customer ID", "Reservation ID", "Payment Date", "Payment Method", "Payment Type", "Refund Status"}, 0);
        paymentsTable = new JTable(tableModel);
        paymentsTable.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(paymentsTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Custom renderer to change row colors based on refund status
        paymentsTable.setDefaultRenderer(Object.class, new RefundStatusRenderer());

        // Load payments
        loadPayments();

        // Add an Exit button at the bottom
        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close only this window
            }
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnExit);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadPayments() {
        // Clear old rows
        tableModel.setRowCount(0);

        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT p.payment_id, p.customer_id, p.reservation_id, p.payment_date, p.payment_method, " +
                         "p.payment_type, p.refund_status " +
                         "FROM payment p";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int paymentId = rs.getInt("payment_id");
                int customerId = rs.getInt("customer_id");
                int reservationId = rs.getInt("reservation_id");
                String paymentDate = rs.getString("payment_date");
                String paymentMethod = rs.getString("payment_method");
                String paymentType = rs.getString("payment_type");
                String refundStatus = rs.getString("refund_status");

                // Add row to the table
                tableModel.addRow(new Object[]{paymentId, customerId, reservationId, paymentDate, paymentMethod, paymentType, refundStatus});
            }
            rs.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching payments.");
        }

        // Refresh table
        tableModel.fireTableDataChanged();
    }

    // Custom renderer to alternate row colors based on refund status
    class RefundStatusRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            // Get the refund status value
            String refundStatus = (String) table.getValueAt(row, 6); // 6th column is "Refund Status"

            // Change background color based on refund status
            if ("Refunded".equalsIgnoreCase(refundStatus)) {
                component.setBackground(new Color(255, 204, 204)); // Light red
            } else if ("Received".equalsIgnoreCase(refundStatus)) {
                component.setBackground(new Color(204, 255, 204)); // Light green
            } else {
                component.setBackground(Color.WHITE); // Default background color
            }

            // Make sure the selected row has a consistent background color
            if (isSelected) {
                component.setBackground(table.getSelectionBackground());
            }

            return component;
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                StaffViewPaymentsPage frame = new StaffViewPaymentsPage();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
