package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class ReservationSummaryPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private List<Room> selectedRooms;
    private String checkInDate;
    private String checkOutDate;
    private double totalPrice;
    private String username;

    public ReservationSummaryPage(List<Room> selectedRooms, String checkInDate, String checkOutDate, double totalPrice, String username) {
        this.selectedRooms = selectedRooms;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.totalPrice = totalPrice;
        this.username = username;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        JTextArea summaryTextArea = new JTextArea();
        summaryTextArea.setEditable(false);
        summaryTextArea.append("Reservation Summary:\n\n");
        summaryTextArea.append("Check-in Date: " + checkInDate + "\n");
        summaryTextArea.append("Check-out Date: " + checkOutDate + "\n\n");
        summaryTextArea.append("Selected Rooms:\n");

        for (Room room : selectedRooms) {
            summaryTextArea.append("Room Number: " + room.getRoomNumber() + ", Type: " + room.getRoomType() + ", Price: RM " + room.getPrice() + "\n");
        }

        summaryTextArea.append("\nTotal Price: RM " + totalPrice);

        contentPane.add(new JScrollPane(summaryTextArea), BorderLayout.CENTER);

        JButton btnProceedToPayment = new JButton("Proceed to Payment");
        btnProceedToPayment.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Convert the date strings to the correct format (YYYY-MM-DD)
                String formattedCheckInDate = formatDate(checkInDate);
                String formattedCheckOutDate = formatDate(checkOutDate);

                PaymentPage paymentPage = new PaymentPage(username, formattedCheckInDate, formattedCheckOutDate, totalPrice);
                paymentPage.setVisible(true);
                dispose();
            }
        });
        contentPane.add(btnProceedToPayment, BorderLayout.SOUTH);
    }

    // Helper method to convert date strings to the correct format (YYYY-MM-DD)
    private String formatDate(String dateStr) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("dd MMMM yyyy");
            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = inputFormat.parse(dateStr);
            return outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}