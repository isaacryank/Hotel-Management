package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import database.MyDatabase;

public class AddMembershipPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtName;
    private JTextArea membershipDetailsArea;
    private String username;

    public AddMembershipPage(String username) {
        this.username = username;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        // Panel for input fields
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(2, 2, 10, 10));
        contentPane.add(inputPanel, BorderLayout.NORTH);

        JLabel lblName = new JLabel("Name:");
        inputPanel.add(lblName);

        txtName = new JTextField();
        inputPanel.add(txtName);
        txtName.setColumns(10);

        // Change "Search" button to "Add Membership" button
        JButton btnAddMembership = new JButton("Add Membership");
        btnAddMembership.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = txtName.getText();
                if (name.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter your name.");
                    return;
                }
                try {
                    int customerId = getCustomerIdByName(name);
                    if (customerId == -1) {
                        JOptionPane.showMessageDialog(null, "Customer not found.");
                        return;
                    }

                    // Check if the customer already has an active membership
                    if (hasActiveMembership(customerId)) {
                        JOptionPane.showMessageDialog(null, "You already have an active membership.");
                        return;
                    }

                    // Display membership details
                    displayMembershipDetails(customerId);

                    // Open the MembershipPaymentPage for payment
                    MembershipPaymentPage paymentPage = new MembershipPaymentPage(username);
                    paymentPage.setVisible(true);
                    dispose(); // Close the current window
                } catch (ClassNotFoundException | SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error accessing the database.");
                }
            }
        });
        inputPanel.add(btnAddMembership);

        // Panel for displaying membership details
        membershipDetailsArea = new JTextArea();
        membershipDetailsArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(membershipDetailsArea);
        contentPane.add(scrollPane, BorderLayout.CENTER);
    }

    private int getCustomerIdByName(String name) throws ClassNotFoundException, SQLException {
        int customerId = -1;
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT customer_id FROM customer WHERE name = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                customerId = rs.getInt("customer_id");
            }
            rs.close();
        }
        return customerId;
    }

    private boolean hasActiveMembership(int customerId) throws ClassNotFoundException, SQLException {
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT * FROM membership WHERE customer_id = ? AND status = 'active'";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // Returns true if an active membership exists
        }
    }

    private void displayMembershipDetails(int customerId) {
        // Calculate start and end dates
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = startDate.plusDays(30);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Display membership details
        membershipDetailsArea.setText("Membership Details:\n");
        membershipDetailsArea.append("Start Date: " + startDate.format(formatter) + "\n");
        membershipDetailsArea.append("End Date: " + endDate.format(formatter) + "\n");
        membershipDetailsArea.append("Loyalty Points: 0\n");
        membershipDetailsArea.append("Status: active\n");
    }

    // Method to update membership status if end date has passed
    public static void updateMembershipStatus() throws ClassNotFoundException, SQLException {
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "UPDATE membership SET status = 'inactive' WHERE enddate < CURDATE() AND status = 'active'";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AddMembershipPage frame = new AddMembershipPage("exampleUsername");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}