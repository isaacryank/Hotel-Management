package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import database.MyDatabase;

public class ViewReservationsPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String username;
    private JTable reservationsTable;
    private DefaultTableModel tableModel;

    public ViewReservationsPage(String username) {
        this.username = username;

        // Change the default close operation to DISPOSE_ON_CLOSE
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Only closes this window
        setBounds(100, 100, 800, 400); // Increased size to accommodate the table
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        // Table setup with new Refund Status column
        tableModel = new DefaultTableModel(new Object[]{"Reservation ID", "Check-in Date", "Check-out Date", "Payment Amount", "Status", "Refund Status", "Action"}, 0);
        reservationsTable = new JTable(tableModel);
        reservationsTable.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(reservationsTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Load reservations
        loadReservations();

        // Add a cancel button for each row
        addCancelButton();

        // Add an Exit button at the bottom
        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close only this window
            }
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnExit);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadReservations() {
        tableModel.setRowCount(0); // Clear existing rows
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT r.reservation_id, r.check_in_date, r.check_out_date, p.payment_amount, r.status, p.refund_status " +
                         "FROM reservation r JOIN payment p ON r.payment_id = p.payment_id " +
                         "JOIN customer c ON r.customer_id = c.customer_id " +
                         "WHERE c.username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int reservationId = rs.getInt("reservation_id");
                String checkInDate = rs.getString("check_in_date");
                String checkOutDate = rs.getString("check_out_date");
                double paymentAmount = rs.getDouble("payment_amount");
                String status = rs.getString("status");
                String refundStatus = rs.getString("refund_status");

                // Debug: Print fetched data
                System.out.println("Fetched Data: " + reservationId + ", " + checkInDate + ", " + checkOutDate + ", " + paymentAmount + ", " + status + ", " + refundStatus);

                // Add row to the table with Refund Status
                tableModel.addRow(new Object[]{reservationId, checkInDate, checkOutDate, paymentAmount, status, refundStatus, "Cancel"});
            }
            rs.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching reservations.");
        }
    }

    private void addCancelButton() {
        // Add a button column to the table
        reservationsTable.getColumn("Action").setCellRenderer(new ButtonRenderer());
        reservationsTable.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox()));
    }

    // Button renderer for the table
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    // Button editor for the table
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean isPushed;
        private int selectedRow;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            isPushed = true;
            selectedRow = row;
            return button;
        }

        public Object getCellEditorValue() {
            if (isPushed) {
                // Handle cancel action
                int reservationId = (int) tableModel.getValueAt(selectedRow, 0);
                String status = (String) tableModel.getValueAt(selectedRow, 4);
                String refundStatus = (String) tableModel.getValueAt(selectedRow, 5);

                // Check if the reservation can be cancelled
                if (!status.equals("cancelled") && !refundStatus.equals("Refunded")) {
                    int option = JOptionPane.showConfirmDialog(ViewReservationsPage.this, 
                            "Are you sure you want to cancel this reservation?", "Confirm Cancellation", JOptionPane.YES_NO_OPTION);
                    if (option == JOptionPane.YES_OPTION) {
                        cancelReservation(reservationId);
                    }
                } else if (refundStatus.equals("Refunded")) {
                    JOptionPane.showMessageDialog(ViewReservationsPage.this, "This reservation has already been refunded.");
                } else {
                    JOptionPane.showMessageDialog(ViewReservationsPage.this, "This reservation is already cancelled.");
                }
            }
            isPushed = false;
            return label;
        }

        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }

    private void cancelReservation(int reservationId) {
        try (Connection conn = MyDatabase.doConnection()) {
            // Step 1: Update the reservation status to 'cancelled'
            String updateReservationSql = "UPDATE reservation SET status = 'cancelled' WHERE reservation_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(updateReservationSql);
            pstmt.setInt(1, reservationId);
            pstmt.executeUpdate();

            // Step 2: Fetch the payment_id associated with this reservation
            String fetchPaymentIdSql = "SELECT payment_id FROM reservation WHERE reservation_id = ?";
            pstmt = conn.prepareStatement(fetchPaymentIdSql);
            pstmt.setInt(1, reservationId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int paymentId = rs.getInt("payment_id");

                // Step 3: Update the refund_status in the payment table
                String updateRefundStatusSql = "UPDATE payment SET refund_status = 'Refunded' WHERE payment_id = ?";
                pstmt = conn.prepareStatement(updateRefundStatusSql);
                pstmt.setInt(1, paymentId);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Reservation cancelled and payment refunded.");
            } else {
                JOptionPane.showMessageDialog(this, "Error: Payment details not found for this reservation.");
            }

            rs.close();
            loadReservations(); // Refresh the table to reflect changes
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error cancelling reservation.");
        }
    }


    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ViewReservationsPage frame = new ViewReservationsPage("exampleUsername"); // Replace with actual username
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}