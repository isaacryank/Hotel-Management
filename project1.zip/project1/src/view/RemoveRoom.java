package view;

import javax.swing.*;
import database.MyDatabase;
import java.awt.*;
import java.sql.*;

public class RemoveRoom extends JFrame {
    private static final long serialVersionUID = 1L;
    private JComboBox<String> cmbRoomId;
    private JRadioButton rbSoftDelete, rbHardDelete;
    private ButtonGroup deleteOptionGroup;
    private JLabel lblExplanation;
    private ManageRoomsPage manageRoomsPage;

    public RemoveRoom(ManageRoomsPage manageRoomsPage) {
        this.manageRoomsPage = manageRoomsPage;

        setTitle("Remove Room");
        setBounds(100, 100, 400, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(6, 1, 10, 10));

        // Room ID Dropdown
        JLabel lblRoomId = new JLabel("Select Room ID:");
        cmbRoomId = new JComboBox<>();
        loadRoomIds();  // Load Room IDs from database
        add(lblRoomId);
        add(cmbRoomId);

        // Delete Option - Radio buttons for Soft and Hard Delete
        JPanel deleteOptionPanel = new JPanel();
        deleteOptionPanel.setLayout(new GridLayout(2, 1));

        rbSoftDelete = new JRadioButton("Soft Delete", true); // Default to Soft Delete
        rbHardDelete = new JRadioButton("Hard Delete");
        deleteOptionGroup = new ButtonGroup();
        deleteOptionGroup.add(rbSoftDelete);
        deleteOptionGroup.add(rbHardDelete);

        deleteOptionPanel.add(rbSoftDelete);
        deleteOptionPanel.add(rbHardDelete);
        add(deleteOptionPanel);

        // Explanation Label
        lblExplanation = new JLabel("<html><i>Soft Delete: Set the room status to 'Not Available'.<br>Hard Delete: Permanently remove the room from the database.</i></html>");
        add(lblExplanation);

        // Remove Button
        JButton btnRemove = new JButton("Remove Room");
        btnRemove.addActionListener(e -> {
            String selectedRoomId = (String) cmbRoomId.getSelectedItem();
            boolean isHardDelete = rbHardDelete.isSelected();

            if (isHardDelete) {
                // Prompt for Hard Delete
                int confirmation = JOptionPane.showConfirmDialog(this,
                        "THIS WILL REMOVE THE ROOM " + selectedRoomId + " FROM THE DATABASE PERMANENTLY\n\n*Hard Deleted data will not be recoverable",
                        "Confirm Hard Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (confirmation == JOptionPane.YES_OPTION) {
                    // Proceed with Hard Delete (Remove from database)
                    hardDeleteRoom(selectedRoomId);
                }
            } else {
                // Soft Delete (Set status to 'Not Available')
                softDeleteRoom(selectedRoomId);
            }
        });
        add(btnRemove);

        // Cancel Button
        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(e -> dispose());
        add(btnCancel);
    }

    private void loadRoomIds() {
        // Fetch room IDs from the database instead of room numbers
        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT room_id FROM room");
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                cmbRoomId.addItem(rs.getString("room_id"));  // Add Room ID to the combo box
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading room IDs: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void softDeleteRoom(String roomId) {
        // Soft Delete: Update status to "Not Available"
        String sql = "UPDATE room SET status = 'Not Available' WHERE room_id = ?";
        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, roomId);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Room " + roomId + " has been soft deleted (status set to 'Not Available').", "Success", JOptionPane.INFORMATION_MESSAGE);
            manageRoomsPage.loadPage(manageRoomsPage.getCurrentPage());  // Refresh room list
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error soft deleting room: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void hardDeleteRoom(String roomId) {
        // Hard Delete: Remove room from the database
        String sql = "DELETE FROM room WHERE room_id = ?";
        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, roomId);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Room " + roomId + " has been permanently removed from the database.", "Success", JOptionPane.INFORMATION_MESSAGE);
            manageRoomsPage.loadPage(manageRoomsPage.getCurrentPage());  // Refresh room list
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error hard deleting room: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
