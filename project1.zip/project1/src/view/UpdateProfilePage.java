package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import database.MyDatabase;

public class UpdateProfilePage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable profileTable;
    private JButton btnSaveChanges;
    private JButton btnExit;
    private String username;

    /**
     * Create the frame.
     * @throws ClassNotFoundException 
     */
    public UpdateProfilePage(String username) throws ClassNotFoundException {
        this.username = username;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Only close this window
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(new BorderLayout(0, 10));

        setContentPane(contentPane);

        // Fetch the current profile data to pre-fill the fields
        String[] customerData = fetchCustomerData(username);

        // Table to display profile data
        String[] columnNames = {"Field", "Value"};
        Object[][] data = {
            {"Email", customerData[0]},
            {"Phone Number", customerData[1]},
            {"Address", customerData[2]},
            {"Password", customerData[3]}
        };

        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 1; // Only the "Value" column is editable
            }
        };

        profileTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(profileTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // Save changes button
        btnSaveChanges = new JButton("Save Changes");
        btnSaveChanges.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Update the customer profile in the database
                try {
                    updateCustomerProfile();
                } catch (ClassNotFoundException e1) {
                    e1.printStackTrace();
                }
            }
        });
        buttonPanel.add(btnSaveChanges);

        // Exit button
        btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close only this window
            }
        });
        buttonPanel.add(btnExit);

        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Fetch current profile data (email, phone, address, password) from the database.
     * @throws ClassNotFoundException 
     */
    private String[] fetchCustomerData(String username) throws ClassNotFoundException {
        String[] customerData = new String[4];
        String sql = "SELECT email, phonenumber, address, c_password FROM customer WHERE username = ?";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                customerData[0] = rs.getString("email");
                customerData[1] = rs.getString("phonenumber");
                customerData[2] = rs.getString("address");
                customerData[3] = rs.getString("c_password");
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerData;
    }

    /**
     * Update the customer's profile in the database.
     * @throws ClassNotFoundException 
     */
    private void updateCustomerProfile() throws ClassNotFoundException {
        String email = (String) profileTable.getModel().getValueAt(0, 1);
        String phone = (String) profileTable.getModel().getValueAt(1, 1);
        String address = (String) profileTable.getModel().getValueAt(2, 1);
        String password = (String) profileTable.getModel().getValueAt(3, 1);

        String sql = "UPDATE customer SET email = ?, phonenumber = ?, address = ?, c_password = ? WHERE username = ?";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);
            pstmt.setString(2, phone);
            pstmt.setString(3, address);
            pstmt.setString(4, password);
            pstmt.setString(5, username);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Profile updated successfully!");
                dispose();  // Close the update page after updating
            } else {
                JOptionPane.showMessageDialog(null, "Failed to update profile.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UpdateProfilePage frame = new UpdateProfilePage("exampleUsername");  // Example username
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}