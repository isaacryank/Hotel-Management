package view;

import controller.UserController;
import model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginView extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtUsername;
    private JPasswordField passwordField;
    private JComboBox<String> comboBoxUsertype;

    // Dimensions and positions (for readability and maintainability)
    private static final int FRAME_WIDTH = 450;
    private static final int FRAME_HEIGHT = 300;
    private static final int BUTTON_WIDTH = 117;
    private static final int BUTTON_HEIGHT = 29;
    private static final int COMBO_BOX_WIDTH = 130;
    private static final int COMBO_BOX_HEIGHT = 26;
    private static final int FIELD_WIDTH = 130;
    private static final int FIELD_HEIGHT = 26;
    
   

    
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LoginView frame = new LoginView();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    

    public LoginView() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, FRAME_WIDTH, FRAME_HEIGHT);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(123, 245, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Label for Menu Login
        JLabel lblNewLabel = new JLabel("Menu Login");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
        lblNewLabel.setBounds(121, 21, 164, 58);
        contentPane.add(lblNewLabel);

        // User Type Label and Combo Box
        JLabel lblUsertype = new JLabel("User Type: ");
        lblUsertype.setHorizontalAlignment(SwingConstants.RIGHT);
        lblUsertype.setBounds(54, 90, 124, 21);
        contentPane.add(lblUsertype);

        comboBoxUsertype = new JComboBox<>();
        comboBoxUsertype.setBounds(200, 87, COMBO_BOX_WIDTH, COMBO_BOX_HEIGHT);
        comboBoxUsertype.addItem("Staff");
        comboBoxUsertype.addItem("Customer");
        contentPane.add(comboBoxUsertype);

        // Username Label and Field
        JLabel lblUsername = new JLabel("Username : ");
        lblUsername.setHorizontalAlignment(SwingConstants.RIGHT);
        lblUsername.setBounds(54, 133, 124, 21);
        contentPane.add(lblUsername);

        txtUsername = new JTextField();
        txtUsername.setBounds(200, 130, FIELD_WIDTH, FIELD_HEIGHT);
        contentPane.add(txtUsername);
        txtUsername.setColumns(10);

        // Password Label and Field
        JLabel lblPassword = new JLabel("Password : ");
        lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
        lblPassword.setBounds(54, 170, 124, 21);
        contentPane.add(lblPassword);

        passwordField = new JPasswordField();
        passwordField.setBounds(200, 167, FIELD_WIDTH + 2, FIELD_HEIGHT);
        contentPane.add(passwordField);

        // Ok Button
        JButton btnOk = new JButton("Ok");
        btnOk.setBounds(94, 210, BUTTON_WIDTH, BUTTON_HEIGHT);
        contentPane.add(btnOk);
        btnOk.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = txtUsername.getText();
                String password = new String(passwordField.getPassword());
                String usertype = (String) comboBoxUsertype.getSelectedItem();

                // Ensure that both username and password are filled in
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter both username and password!");
                    return;
                }

                User user = new User();
                user.setName(username);
                user.setPassword(password);

                UserController login = new UserController();
                try {
                    // Pass usertype to login controller for authentication
                    Integer staffId = login.doLogin(user, usertype);

                    if (staffId != null) { // Login is successful for staff
                        // Login is successful, navigate to respective main page
                        JOptionPane.showMessageDialog(null, "Login Successful!");
                        System.out.println("Login successful for user: " + username);

                        if ("Customer".equalsIgnoreCase(usertype)) {
                            CustomerMainPage customerMain = new CustomerMainPage(username);
                            customerMain.setVisible(true);
                        } else if ("Staff".equalsIgnoreCase(usertype)) {
                            // Redirect staff user to StaffMainPage
                            StaffMainPage staffMainPage = new StaffMainPage(staffId);
                            staffMainPage.setVisible(true);
                        }
                        dispose();  // Close the current login window
                    } else {
                        // User not found, show appropriate message
                        JOptionPane.showMessageDialog(null, "Username or password not found!");
                        System.out.println("Failed login attempt for user: " + username);
                    }

                } catch (Exception e1) {
                    e1.printStackTrace();
                    JOptionPane.showMessageDialog(null, "An error occurred while processing your login.");
                }
            }
        });

        // Cancel Button
        JButton btnCancel = new JButton("Cancel");
        btnCancel.setBounds(202, 210, BUTTON_WIDTH, BUTTON_HEIGHT);
        contentPane.add(btnCancel);
        btnCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                txtUsername.setText("");
                passwordField.setText("");
                comboBoxUsertype.setSelectedIndex(0); // Reset to default value
            }
        });

        // Register Button
        JButton btnRegister = new JButton("Register");
        btnRegister.setBounds(313, 210, BUTTON_WIDTH, BUTTON_HEIGHT);
        contentPane.add(btnRegister);
        btnRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RegisterUserView().setVisible(true);
                dispose();  // Close login window
            }
        });
    }
}
