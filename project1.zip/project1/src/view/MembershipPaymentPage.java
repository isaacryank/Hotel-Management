package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;
import database.MyDatabase;
import java.util.regex.Pattern;

public class MembershipPaymentPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String username;
    private double membershipFee = 100.00; // Example membership fee

    private JTextField txtCardNumberPart1;
    private JTextField txtCardNumberPart2;
    private JTextField txtCardNumberPart3;
    private JTextField txtExpiryMonth;
    private JTextField txtExpiryYear;
    private JTextField txtCVV;

    public MembershipPaymentPage(String username) {
        this.username = username;

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        JTextArea paymentTextArea = new JTextArea();
        paymentTextArea.setEditable(false);
        paymentTextArea.append("Membership Payment Details:\n\n");
        paymentTextArea.append("Membership Fee: RM " + membershipFee + "\n\n");
        paymentTextArea.append("Please enter your payment details:");

        contentPane.add(new JScrollPane(paymentTextArea), BorderLayout.NORTH);

        // Payment Details Panel
        JPanel paymentDetailsPanel = new JPanel();
        paymentDetailsPanel.setLayout(new GridLayout(4, 2, 10, 10));
        paymentDetailsPanel.setBorder(BorderFactory.createTitledBorder("Payment Details"));

        // Card Number
        JLabel lblCardNumber = new JLabel("Card Number:");
        JPanel cardNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        txtCardNumberPart1 = createFixedSizeTextField(4);
        txtCardNumberPart2 = createFixedSizeTextField(4);
        txtCardNumberPart3 = createFixedSizeTextField(4);
        cardNumberPanel.add(txtCardNumberPart1);
        cardNumberPanel.add(new JLabel("-"));
        cardNumberPanel.add(txtCardNumberPart2);
        cardNumberPanel.add(new JLabel("-"));
        cardNumberPanel.add(txtCardNumberPart3);

        // Expiry Date
        JLabel lblExpiryDate = new JLabel("Expiry Date:");
        JPanel expiryDatePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        txtExpiryMonth = createFixedSizeTextField(2);
        txtExpiryYear = createFixedSizeTextField(2);
        expiryDatePanel.add(txtExpiryMonth);
        expiryDatePanel.add(new JLabel("/"));
        expiryDatePanel.add(txtExpiryYear);

        // CVV
        JLabel lblCVV = new JLabel("CVV:");
        txtCVV = createFixedSizeTextField(3);

        paymentDetailsPanel.add(lblCardNumber);
        paymentDetailsPanel.add(cardNumberPanel);
        paymentDetailsPanel.add(lblExpiryDate);
        paymentDetailsPanel.add(expiryDatePanel);
        paymentDetailsPanel.add(lblCVV);
        paymentDetailsPanel.add(txtCVV);

        contentPane.add(paymentDetailsPanel, BorderLayout.CENTER);

        // Confirm Payment Button
        JButton btnConfirmPayment = new JButton("Confirm Payment");
        btnConfirmPayment.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String cardNumber = txtCardNumberPart1.getText() + txtCardNumberPart2.getText() + txtCardNumberPart3.getText();
                String expiryDate = txtExpiryMonth.getText() + "/" + txtExpiryYear.getText();
                String cvv = txtCVV.getText();

                // Validate inputs
                if (!validateCardNumber(cardNumber)) {
                    JOptionPane.showMessageDialog(null, "Invalid card number. Format: XXXX-XXXX-XXXX");
                    return;
                }
                if (!validateExpiryDate(expiryDate)) {
                    JOptionPane.showMessageDialog(null, "Invalid expiry date. Format: MM/YY");
                    return;
                }
                if (!validateCVV(cvv)) {
                    JOptionPane.showMessageDialog(null, "Invalid CVV. Must be a 3-digit number.");
                    return;
                }

                // Save payment and update membership
                try {
                    int paymentId = savePayment("Debit/Credit Card");
                    if (paymentId != -1) {
                        int customerId = getCustomerId(username);
                        if (customerId == -1) {
                            throw new SQLException("Customer not found for username: " + username);
                        }

                        // Insert membership and get member_id
                        int memberId = insertMembership(customerId);
                        if (memberId != -1) {
                            // Update customer table with member_id
                            updateCustomerMemberId(customerId, memberId);

                            JOptionPane.showMessageDialog(null, "Payment successful! Membership added.");
                            dispose(); // Close the payment window
                            new AddMembershipPage(username).setVisible(true); // Open the membership page
                        } else {
                            JOptionPane.showMessageDialog(null, "Error creating membership.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Error processing payment.");
                    }
                } catch (ClassNotFoundException | SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error processing payment: " + ex.getMessage());
                }
            }
        });

        // Exit Button
        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close only this window
            }
        });

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(btnConfirmPayment);
        buttonPanel.add(btnExit);

        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    // Helper method to create a fixed-size JTextField
    private JTextField createFixedSizeTextField(int columns) {
        JTextField textField = new JTextField(columns);
        textField.setHorizontalAlignment(JTextField.CENTER);
        textField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume(); // Ignore non-digit characters
                }
            }
        });
        return textField;
    }

    private boolean validateCardNumber(String cardNumber) {
        return Pattern.matches("\\d{12}", cardNumber); // 12 digits without hyphens
    }

    private boolean validateExpiryDate(String expiryDate) {
        return Pattern.matches("\\d{2}/\\d{2}", expiryDate);
    }

    private boolean validateCVV(String cvv) {
        return Pattern.matches("\\d{3}", cvv);
    }

    private int savePayment(String paymentMethod) throws ClassNotFoundException, SQLException {
        try (Connection conn = MyDatabase.doConnection()) {
            // Get the customer_id for the given username
            int customerId = getCustomerId(username);
            if (customerId == -1) {
                throw new SQLException("Customer not found for username: " + username);
            }

            // Insert the payment
            String sql = "INSERT INTO payment (customer_id, payment_date, payment_amount, payment_method, payment_type) " +
                         "VALUES (?, CURDATE(), ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            pstmt.setInt(1, customerId);
            pstmt.setDouble(2, membershipFee);
            pstmt.setString(3, paymentMethod);
            pstmt.setString(4, "Membership"); // Payment type is "Membership"

            pstmt.executeUpdate();

            // Retrieve the generated payment_id
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1); // Return the payment_id
            }
            return -1; // If no payment_id was generated
        }
    }

    private int getCustomerId(String username) throws SQLException, ClassNotFoundException {
        int customerId = -1;
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT customer_id FROM customer WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                customerId = rs.getInt("customer_id");
            } else {
                System.out.println("Customer not found for username: " + username); // Debugging
            }
            rs.close();
        }
        return customerId;
    }

    private int insertMembership(int customerId) throws SQLException, ClassNotFoundException {
        try (Connection conn = MyDatabase.doConnection()) {
            // Insert the membership
            String sql = "INSERT INTO membership (customer_id, startdate, enddate, status) " +
                         "VALUES (?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 YEAR), 'Active')";
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            pstmt.setInt(1, customerId);

            pstmt.executeUpdate();

            // Retrieve the generated member_id
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1); // Return the member_id
            }
            return -1; // If no member_id was generated
        }
    }

    private void updateCustomerMemberId(int customerId, int memberId) throws SQLException, ClassNotFoundException {
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "UPDATE customer SET member_id = ? WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1, memberId);
            pstmt.setInt(2, customerId);

            pstmt.executeUpdate();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MembershipPaymentPage frame = new MembershipPaymentPage("exampleUsername");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}