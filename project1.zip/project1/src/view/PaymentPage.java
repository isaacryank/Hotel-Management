package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import database.MyDatabase;
import java.sql.*;
import java.util.regex.Pattern;

public class PaymentPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String username;
    private String checkInDate;
    private String checkOutDate;
    private final double[] totalPriceHolder = new double[1]; // Array to hold totalPrice
    private int loyaltyPoints = 0;
    private boolean hasDiscount = false;

    private JTextField txtCardNumberPart1;
    private JTextField txtCardNumberPart2;
    private JTextField txtCardNumberPart3;
    private JTextField txtExpiryMonth;
    private JTextField txtExpiryYear;
    private JTextField txtCVV;
    private JButton btnGetDiscount;
    private JLabel lblLoyaltyPoints;

    public PaymentPage(String username, String checkInDate, String checkOutDate, double totalPrice) {
        this.username = username;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.totalPriceHolder[0] = totalPrice; // Initialize the array with totalPrice

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 500); // Adjusted size for better layout
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(10, 10));

        // Payment Details Panel
        JPanel paymentDetailsPanel = new JPanel();
        paymentDetailsPanel.setLayout(new GridBagLayout());
        paymentDetailsPanel.setBorder(BorderFactory.createTitledBorder("Payment Details"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Padding
        gbc.anchor = GridBagConstraints.WEST; // Align components to the left

        // Card Number
        gbc.gridx = 0;
        gbc.gridy = 0;
        paymentDetailsPanel.add(new JLabel("Card Number:"), gbc);

        JPanel cardNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        txtCardNumberPart1 = createFixedSizeTextField(4);
        txtCardNumberPart2 = createFixedSizeTextField(4);
        txtCardNumberPart3 = createFixedSizeTextField(4);
        cardNumberPanel.add(txtCardNumberPart1);
        cardNumberPanel.add(new JLabel("-"));
        cardNumberPanel.add(txtCardNumberPart2);
        cardNumberPanel.add(new JLabel("-"));
        cardNumberPanel.add(txtCardNumberPart3);

        gbc.gridx = 1;
        gbc.gridy = 0;
        paymentDetailsPanel.add(cardNumberPanel, gbc);

        // Expiry Date
        gbc.gridx = 0;
        gbc.gridy = 1;
        paymentDetailsPanel.add(new JLabel("Expiry Date:"), gbc);

        JPanel expiryDatePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        txtExpiryMonth = createFixedSizeTextField(2);
        txtExpiryYear = createFixedSizeTextField(2);
        expiryDatePanel.add(txtExpiryMonth);
        expiryDatePanel.add(new JLabel("/"));
        expiryDatePanel.add(txtExpiryYear);

        gbc.gridx = 1;
        gbc.gridy = 1;
        paymentDetailsPanel.add(expiryDatePanel, gbc);

        // CVV
        gbc.gridx = 0;
        gbc.gridy = 2;
        paymentDetailsPanel.add(new JLabel("CVV:"), gbc);

        txtCVV = createFixedSizeTextField(3);
        gbc.gridx = 1;
        gbc.gridy = 2;
        paymentDetailsPanel.add(txtCVV, gbc);

        // Loyalty Points
        gbc.gridx = 0;
        gbc.gridy = 3;
        paymentDetailsPanel.add(new JLabel("Loyalty Points:"), gbc);

        lblLoyaltyPoints = new JLabel("0");
        gbc.gridx = 1;
        gbc.gridy = 3;
        paymentDetailsPanel.add(lblLoyaltyPoints, gbc);

        // Get Discount Button
        btnGetDiscount = new JButton("Get 50% Discount");
        btnGetDiscount.setEnabled(false); // Disabled by default
        btnGetDiscount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (loyaltyPoints >= 100) {
                    double discountedPrice = totalPriceHolder[0] * 0.5; // Calculate the discounted price
                    totalPriceHolder[0] = discountedPrice; // Update the total price in the array
                    JOptionPane.showMessageDialog(null, "50% Discount Applied!\nNew Total Price: RM " + totalPriceHolder[0]);
                    hasDiscount = true;
                    btnGetDiscount.setEnabled(false); // Disable the button after applying discount

                    // Update the UI to reflect the new total price
                    updatePaymentDetailsUI(totalPriceHolder[0]);
                }
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2; // Span across two columns
        gbc.anchor = GridBagConstraints.CENTER; // Center the button
        paymentDetailsPanel.add(btnGetDiscount, gbc);

        contentPane.add(paymentDetailsPanel, BorderLayout.CENTER);

        // Confirm Payment Button
        JButton btnConfirmPayment = new JButton("Confirm Payment");
        btnConfirmPayment.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String cardNumber = txtCardNumberPart1.getText() + txtCardNumberPart2.getText() + txtCardNumberPart3.getText();
                String expiryDate = txtExpiryMonth.getText() + "/" + txtExpiryYear.getText();
                String cvv = txtCVV.getText();

                // Validate inputs
                if (!validateCardNumber(cardNumber)) {
                    JOptionPane.showMessageDialog(null, "Invalid card number. Format: XXXX-XXXX-XXXX");
                    return;
                }
                if (!validateExpiryDate(expiryDate)) {
                    JOptionPane.showMessageDialog(null, "Invalid expiry date. Format: MM/YY");
                    return;
                }
                if (!validateCVV(cvv)) {
                    JOptionPane.showMessageDialog(null, "Invalid CVV. Must be a 3-digit number.");
                    return;
                }

                // Save payment
                try {
                    int reservationId = getReservationId();
                    if (reservationId == -1) {
                        JOptionPane.showMessageDialog(null, "Reservation not found for the given details.");
                        return;
                    }

                    // Fetch the roomnumber for the reservation
                    String roomNumber = getRoomNumberForReservation(reservationId);
                    if (roomNumber == null) {
                        JOptionPane.showMessageDialog(null, "Room number not found for the reservation.");
                        return;
                    }

                    int paymentId = savePayment("Debit/Credit Card", reservationId);
                    if (paymentId != -1) {
                        updateReservationWithPaymentId(paymentId, reservationId, roomNumber); // Pass reservation_id and roomnumber
                        JOptionPane.showMessageDialog(null, "Payment successful!");

                        // Add loyalty points if payment type is "Reservation"
                        if (hasDiscount) {
                            updateLoyaltyPoints(-100); // Deduct 100 points for the discount
                        } else {
                            updateLoyaltyPoints(20); // Add 20 loyalty points
                        }

                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Error processing payment.");
                    }
                } catch (ClassNotFoundException | SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error processing payment: " + ex.getMessage());
                }
            }
        });

        // Panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(btnConfirmPayment);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        // Fetch loyalty points and enable discount button if applicable
        fetchLoyaltyPoints();
    }

    // Helper method to create a fixed-size JTextField
    private JTextField createFixedSizeTextField(int columns) {
        JTextField textField = new JTextField(columns);
        textField.setHorizontalAlignment(JTextField.CENTER);
        textField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume(); // Ignore non-digit characters
                }
            }
        });
        return textField;
    }

    private boolean validateCardNumber(String cardNumber) {
        return Pattern.matches("\\d{12}", cardNumber); // 12 digits without hyphens
    }

    private boolean validateExpiryDate(String expiryDate) {
        return Pattern.matches("\\d{2}/\\d{2}", expiryDate);
    }

    private boolean validateCVV(String cvv) {
        return Pattern.matches("\\d{3}", cvv);
    }

    private int savePayment(String paymentMethod, int reservationId) throws ClassNotFoundException, SQLException {
        try (Connection conn = MyDatabase.doConnection()) {
            // Get the customer_id for the given username
            int customerId = getCustomerId(username);
            if (customerId == -1) {
                throw new SQLException("Customer not found for username: " + username);
            }

            // Insert the payment
            String sql = "INSERT INTO payment (customer_id, payment_date, payment_amount, payment_method, payment_type, reservation_id) " +
                         "VALUES (?, CURDATE(), ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            pstmt.setInt(1, customerId);
            pstmt.setDouble(2, totalPriceHolder[0]); // Use the value from the array
            pstmt.setString(3, paymentMethod);
            pstmt.setString(4, "Reservation"); // Payment type is "Reservation"
            pstmt.setInt(5, reservationId); // Add reservation_id to the payment

            pstmt.executeUpdate();

            // Retrieve the generated payment_id
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1); // Return the payment_id
            }
            return -1; // If no payment_id was generated
        }
    }

    private void updateReservationWithPaymentId(int paymentId, int reservationId, String roomNumber) throws ClassNotFoundException, SQLException {
        try (Connection conn = MyDatabase.doConnection()) {
            // Update the reservation table with the payment_id for the specific reservation_id and roomnumber
            String sql = "UPDATE reservation SET payment_id = ? WHERE reservation_id = ? AND roomnumber = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1, paymentId);
            pstmt.setInt(2, reservationId);
            pstmt.setString(3, roomNumber);

            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Reservation updated successfully with payment_id: " + paymentId);
            } else {
                System.out.println("No reservation found with reservation_id: " + reservationId + " and roomnumber: " + roomNumber);
            }
        }
    }

    private int getCustomerId(String username) throws SQLException, ClassNotFoundException {
        int customerId = -1;
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT customer_id FROM customer WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                customerId = rs.getInt("customer_id");
            } else {
                System.out.println("Customer not found for username: " + username); // Debugging
            }
            rs.close();
        }
        return customerId;
    }

    private int getReservationId() throws ClassNotFoundException, SQLException {
        int reservationId = -1;
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT reservation_id FROM reservation WHERE customer_id = (SELECT customer_id FROM customer WHERE username = ?) " +
                         "AND check_in_date = ? AND check_out_date = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, checkInDate);
            pstmt.setString(3, checkOutDate);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                reservationId = rs.getInt("reservation_id");
            } else {
                System.out.println("Reservation not found for the given details."); // Debugging
            }
            rs.close();
        }
        return reservationId;
    }

    private String getRoomNumberForReservation(int reservationId) throws ClassNotFoundException, SQLException {
        String roomNumber = null;
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT roomnumber FROM reservation WHERE reservation_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, reservationId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                roomNumber = rs.getString("roomnumber");
            } else {
                System.out.println("Room number not found for reservation_id: " + reservationId);
            }
            rs.close();
        }
        return roomNumber;
    }

    private void fetchLoyaltyPoints() {
        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT m.loyalty_points FROM membership m JOIN customer c ON m.member_id = c.member_id WHERE c.username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                loyaltyPoints = rs.getInt("loyalty_points");
                lblLoyaltyPoints.setText(String.valueOf(loyaltyPoints));

                // Enable discount button if loyalty points are 100 or more
                if (loyaltyPoints >= 100) {
                    btnGetDiscount.setEnabled(true);
                }
            }
            rs.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateLoyaltyPoints(int pointsToAdd) {
        try (Connection conn = MyDatabase.doConnection()) {
            // Fetch customer_id for the logged-in user
            int customerId = getCustomerId(username);
            if (customerId == -1) {
                System.out.println("Customer not found for username: " + username);
                return;
            }

            // Update loyalty points in the membership table using customer_id
            String updateSql = "UPDATE membership SET loyalty_points = loyalty_points + ? WHERE customer_id = ?";
            PreparedStatement updateStmt = conn.prepareStatement(updateSql);
            updateStmt.setInt(1, pointsToAdd);
            updateStmt.setInt(2, customerId);
            int rowsUpdated = updateStmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Loyalty points updated successfully. Added: " + pointsToAdd);
            } else {
                System.out.println("Failed to update loyalty points. Customer may not have a membership.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void updatePaymentDetailsUI(double newTotalPrice) {
        // Update the payment details text area or label to reflect the new total price
        JTextArea paymentTextArea = (JTextArea) ((JScrollPane) contentPane.getComponent(0)).getViewport().getView();
        paymentTextArea.setText("Payment Details:\n\n" +
                                "Check-in Date: " + checkInDate + "\n" +
                                "Check-out Date: " + checkOutDate + "\n" +
                                "Total Price: RM " + newTotalPrice + "\n\n" +
                                "Please enter your payment details:");
    }
}