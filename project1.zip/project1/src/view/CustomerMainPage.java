package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import database.MyDatabase;

public class CustomerMainPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblWelcomeMessage;
    private static String customerName;

    /**
     * Fetch the customer's name from the database based on the username.
     * @param username The username of the customer.
     * @return The customer's full name.
     * @throws ClassNotFoundException 
     */
    private String fetchCustomerNameFromDatabase(String username) throws ClassNotFoundException {
        String customerName = null;
        String sql = "SELECT name FROM customer WHERE username = ?";

        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username); // Set the username parameter
            ResultSet resultSet = pstmt.executeQuery();

            if (resultSet.next()) {
                customerName = resultSet.getString("name"); // Fetch the customer's name
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerName;
    }

    /**
     * Create the frame.
     * @throws ClassNotFoundException 
     */
    public CustomerMainPage(String username) throws ClassNotFoundException {
        CustomerMainPage.customerName = fetchCustomerNameFromDatabase(username);  // Fetch the customer name based on username

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));

        setContentPane(contentPane);

        // Welcome Message
        lblWelcomeMessage = new JLabel("Welcome, " + (customerName != null ? customerName : "Guest") + "!");
        lblWelcomeMessage.setFont(new Font("Arial", Font.BOLD, 22));
        lblWelcomeMessage.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblWelcomeMessage, BorderLayout.NORTH);

        // Button Panel for options
        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new GridLayout(5, 1, 15, 15));  // Adjusted grid for better spacing
        contentPane.add(optionsPanel, BorderLayout.CENTER);

        // Option 1: View Profile
        JButton btnViewProfile = createStyledButton("View Profile");
        btnViewProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open View Profile page
                ViewProfilePage viewProfilePage = null;
				try {
					viewProfilePage = new ViewProfilePage(username);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}  // Assuming there's a ViewProfilePage class
                viewProfilePage.setVisible(true);
            }
        });
        optionsPanel.add(btnViewProfile);

        // Option 2: Make New Reservation
        JButton btnMakeReservation = createStyledButton("Make New Reservation");
        btnMakeReservation.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open Make Reservation page
                MakeReservationPage makeReservationPage = null;
				try {
					makeReservationPage = new MakeReservationPage(username);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}  // Assuming there's a MakeReservationPage class
                makeReservationPage.setVisible(true);
            }
        });
        optionsPanel.add(btnMakeReservation);

        // Option 3: View Reservations
        JButton btnViewReservations = createStyledButton("View Reservations");
        btnViewReservations.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open View Reservations page
                ViewReservationsPage viewReservationsPage = new ViewReservationsPage(username);  // Assuming there's a ViewReservationsPage class
                viewReservationsPage.setVisible(true);
            }
        });
        optionsPanel.add(btnViewReservations);

        // Option 4: View Payments
        JButton btnViewPayments = createStyledButton("View Payments");
        btnViewPayments.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open View Payments page
                ViewPaymentsPage viewPaymentsPage = new ViewPaymentsPage(username);  // Assuming there's a ViewPaymentsPage class
                viewPaymentsPage.setVisible(true);
            }
        });
        optionsPanel.add(btnViewPayments);

        // Option 5: Add Membership
        JButton btnAddMembership = createStyledButton("Add Membership");
        btnAddMembership.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open Add Membership page
                AddMembershipPage addMembershipPage = new AddMembershipPage(username);  // Assuming there's an AddMembershipPage class
                addMembershipPage.setVisible(true);
            }
        });
        optionsPanel.add(btnAddMembership);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(41, 64, 122));  // Dark blue color for the button
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 50));
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI());  // Remove default button border
        
        button.setBorder(BorderFactory.createLineBorder(new Color(32, 56, 103), 2)); // Subtle border with a dark tone
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));  // Change cursor to hand on hover

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(34, 56, 98));  // Darker shade for hover effect
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(41, 64, 122));  // Original dark blue color
            }
        });

        return button;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        CustomerMainPage.customerName = customerName;
    }
}
