package view;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import database.MyDatabase;

public class AddRoom extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField txtRoomNumber, txtRoomPrice;
    private JComboBox<String> cmbRoomType, cmbStatus;  // ComboBox for room type and status
    private ManageRoomsPage manageRoomsPage;

    public AddRoom(ManageRoomsPage manageRoomsPage) {
        this.manageRoomsPage = manageRoomsPage;
        setTitle("Add Room");
        setBounds(100, 100, 400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));

        // Room Number
        JLabel lblRoomNumber = new JLabel("Room Number (e.g., R017):");
        txtRoomNumber = new JTextField();
        txtRoomNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent e) {
                String roomNumber = txtRoomNumber.getText().trim();
                if (!roomNumber.startsWith("R") && !roomNumber.isEmpty()) {
                    txtRoomNumber.setText("R" + roomNumber);  // Automatically add 'R' if missing
                }
            }
        });
        add(lblRoomNumber);
        add(txtRoomNumber);

        // Room Type - ComboBox with options
        JLabel lblRoomType = new JLabel("Room Type:");
        cmbRoomType = new JComboBox<>(new String[]{"Single", "Double", "Suite"});
        add(lblRoomType);
        add(cmbRoomType);

        // Room Price
        JLabel lblRoomPrice = new JLabel("Room Price (e.g., RM500):");
        txtRoomPrice = new JTextField();
        add(lblRoomPrice);
        add(txtRoomPrice);

        // Status - ComboBox with options
        JLabel lblStatus = new JLabel("Status:");
        cmbStatus = new JComboBox<>(new String[]{"Available", "Not Available"});
        add(lblStatus);
        add(cmbStatus);

        // Add Button
        JButton btnAdd = new JButton("Add Room");
        btnAdd.addActionListener(e -> {
            String roomNumber = txtRoomNumber.getText().trim();
            String roomType = (String) cmbRoomType.getSelectedItem();  // Get selected room type
            String roomPriceStr = txtRoomPrice.getText().trim();
            String status = (String) cmbStatus.getSelectedItem();  // Get selected status

            try {
                // Validate input
                if (roomNumber.isEmpty() || roomPriceStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Room Number and Price must be filled out.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Remove the RM prefix from room price input (if any)
                if (roomPriceStr.startsWith("RM")) {
                    roomPriceStr = roomPriceStr.substring(2).trim();  // Remove RM
                }

                double roomPrice = Double.parseDouble(roomPriceStr);
                if (roomPrice <= 0) {
                    JOptionPane.showMessageDialog(this, "Room price must be greater than 0.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Add room to the database
                String sql = "INSERT INTO room (roomnumber, roomtype, roomprice, status) VALUES (?, ?, ?, ?)";
                try (Connection conn = MyDatabase.doConnection();
                     PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, roomNumber);  // Room number is stored with 'R' as prefix
                    pstmt.setString(2, roomType);
                    pstmt.setDouble(3, roomPrice);
                    pstmt.setString(4, status);

                    pstmt.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Room added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                    // Refresh the room list in ManageRoomsPage by calling loadPage
                    manageRoomsPage.loadPage(manageRoomsPage.getCurrentPage()); // Reload the current page
                    dispose(); // Close the AddRoom window
                } catch (ClassNotFoundException e1) {
                    e1.printStackTrace();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Room price must be a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error adding room: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        add(btnAdd);

        // Cancel Button
        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(e -> dispose());
        add(btnCancel);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ManageRoomsPage manageRoomsPage = new ManageRoomsPage(); // You can instantiate ManageRoomsPage here for testing
                AddRoom frame = new AddRoom(manageRoomsPage);
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
