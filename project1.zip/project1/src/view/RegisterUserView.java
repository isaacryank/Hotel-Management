package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import controller.UserController;
import model.User;
import java.sql.SQLException;
import java.util.ArrayList;

public class RegisterUserView extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtName;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JPasswordField txtRetypePassword;
    private JTextField txtEmail;
    private JTextField txtPhonenumber;
    private JTextField txtAddress;
    private JComboBox<String> comboBoxUsertype;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                RegisterUserView frame = new RegisterUserView();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public RegisterUserView() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 540, 450); // Increased height for the name field
        contentPane = new JPanel();
        contentPane.setBackground(new Color(123, 245, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblRegisterUser = new JLabel("Register User");
        lblRegisterUser.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
        lblRegisterUser.setHorizontalAlignment(SwingConstants.CENTER);
        lblRegisterUser.setBounds(161, 10, 222, 41);
        contentPane.add(lblRegisterUser);

        // Name field
        JLabel lblName = new JLabel("Name:");
        lblName.setHorizontalAlignment(SwingConstants.RIGHT);
        lblName.setBounds(68, 67, 102, 16);
        contentPane.add(lblName);

        txtName = new JTextField();
        txtName.setBounds(188, 63, 195, 26);
        contentPane.add(txtName);

        // Username field
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setHorizontalAlignment(SwingConstants.RIGHT);
        lblUsername.setBounds(68, 107, 102, 16);
        contentPane.add(lblUsername);

        txtUsername = new JTextField();
        txtUsername.setBounds(188, 103, 195, 26);
        contentPane.add(txtUsername);

        // Password field
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
        lblPassword.setBounds(68, 147, 102, 16);
        contentPane.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(188, 143, 195, 26);
        contentPane.add(txtPassword);

        // Retype Password field
        JLabel lblRetypePassword = new JLabel("Retype Password:");
        lblRetypePassword.setHorizontalAlignment(SwingConstants.RIGHT);
        lblRetypePassword.setBounds(7, 190, 163, 16);
        contentPane.add(lblRetypePassword);

        txtRetypePassword = new JPasswordField();
        txtRetypePassword.setBounds(188, 186, 195, 26);
        contentPane.add(txtRetypePassword);

        // Email field
        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setHorizontalAlignment(SwingConstants.RIGHT);
        lblEmail.setBounds(125, 230, 45, 13);
        contentPane.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(188, 224, 195, 26);
        contentPane.add(txtEmail);

        // Phone Number field
        JLabel lblPhonenumber = new JLabel("Phone Number:");
        lblPhonenumber.setHorizontalAlignment(SwingConstants.RIGHT);
        lblPhonenumber.setBounds(68, 260, 102, 16);
        contentPane.add(lblPhonenumber);

        txtPhonenumber = new JTextField();
        txtPhonenumber.setBounds(188, 256, 195, 26);
        contentPane.add(txtPhonenumber);
        txtPhonenumber.setColumns(10);

        // Address field
        JLabel lblAddress = new JLabel("Address:");
        lblAddress.setHorizontalAlignment(SwingConstants.RIGHT);
        lblAddress.setBounds(68, 290, 102, 16);
        contentPane.add(lblAddress);

        txtAddress = new JTextField();
        txtAddress.setBounds(188, 286, 195, 26);
        contentPane.add(txtAddress);
        txtAddress.setColumns(10);

        // Usertype ComboBox
        JLabel lblUsertype = new JLabel("Usertype:");
        lblUsertype.setHorizontalAlignment(SwingConstants.RIGHT);
        lblUsertype.setBounds(68, 320, 102, 16);
        contentPane.add(lblUsertype);

        comboBoxUsertype = new JComboBox<>();
        comboBoxUsertype.setBounds(188, 316, 195, 26);
        comboBoxUsertype.addItem("Customer");
        comboBoxUsertype.addItem("Staff");
        contentPane.add(comboBoxUsertype);

        // Save Button
        JButton btnSave = new JButton("Save");
        btnSave.setBounds(125, 358, 117, 29);
        contentPane.add(btnSave);

        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = txtName.getText();
                String username = txtUsername.getText();
                String password = new String(txtPassword.getPassword());
                String repassword = new String(txtRetypePassword.getPassword());
                String email = txtEmail.getText();
                String usertype = (String) comboBoxUsertype.getSelectedItem();
                String phonenumber = txtPhonenumber.getText();
                String address = txtAddress.getText();

                if (name.isEmpty() || username.isEmpty() || password.isEmpty() || repassword.isEmpty() || email.isEmpty() || usertype == null || phonenumber.isEmpty() || address.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields must be filled out!");
                    return;
                }

                if (!password.equals(repassword)) {
                    JOptionPane.showMessageDialog(null, "Passwords do not match!");
                    return;
                }

                User user = new User();
                user.setName(name);  // Set name
                user.setUsername(username);
                user.setPassword(password);
                user.setRepassword(repassword);
                user.setEmail(email);
                user.setUsertype(usertype);
                user.setPhonenumber(phonenumber);
                user.setAddress(address);

                UserController register = new UserController();
                try {
                    ArrayList<User> users = register.getUsers(usertype);  // Pass usertype to handle different table insertions
                    boolean userExists = users.stream().anyMatch(u -> u.getName().equals(username));

                    if (userExists) {
                        JOptionPane.showMessageDialog(null, "User already exists. Try a different username.");
                    } else {
                        int insertSuccess = register.addUser(user, usertype);
                        if (insertSuccess > 0) {
                            JOptionPane.showMessageDialog(null, "User registered successfully!");
                            dispose();
                        } else {
                            JOptionPane.showMessageDialog(null, "Error while registering. Please try again.");
                        }
                    }
                } catch (ClassNotFoundException | SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error occurred while connecting to the database.");
                    ex.printStackTrace();
                }
            }
        });

        // Cancel Button
        JButton btnCancel = new JButton("Cancel");
        btnCancel.setBounds(240, 358, 117, 29);
        contentPane.add(btnCancel);

        btnCancel.addActionListener(e -> dispose());
    }
}
