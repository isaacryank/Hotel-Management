package controller;

import java.sql.*;
import java.util.ArrayList;

import database.MyDatabase;
import model.User;

public class UserController {

    // Method to add a new user (either staff or customer)
	public int addUser(User user, String usertype) throws ClassNotFoundException, SQLException {
	    int success = -1;
	    String sql = "";

	    // Sanitize user inputs (this is a basic approach, consider more robust validation)
	    String username = user.getUsername().replace("'", "''");
	    String name = user.getName().replace("'", "''");
	    String password = user.getPassword().replace("'", "''");
	    String email = user.getEmail().replace("'", "''");
	    String phonenumber = user.getPhonenumber().replace("'", "''");
	    String address = user.getAddress().replace("'", "''");

	    // Determine which table to insert into based on usertype
	    if ("Staff".equalsIgnoreCase(usertype)) {
	        sql = "INSERT INTO staff (name, username, s_password, email, phonenumber, address) VALUES (?, ?, ?, ?, ?, ?)";
	    } else if ("Customer".equalsIgnoreCase(usertype)) {
	        sql = "INSERT INTO customer (name, username, c_password, email, phonenumber, address) VALUES (?, ?, ?, ?, ?, ?)";
	    }

	    // Using PreparedStatement to prevent SQL injection
	    try (Connection conn = MyDatabase.doConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {

	        pstmt.setString(1, name);
	        pstmt.setString(2, username);
	        pstmt.setString(3, password);
	        pstmt.setString(4, email);
	        pstmt.setString(5, phonenumber);
	        pstmt.setString(6, address);

	        success = pstmt.executeUpdate();
	    }

	    return success;
	}


    // Method for login authentication
	public Integer doLogin(User user, String usertype) throws ClassNotFoundException, SQLException {
	    Integer staffId = null;
	    String sql = "";

	    // Determine the table and columns based on usertype
	    if ("Staff".equalsIgnoreCase(usertype)) {
	        sql = "SELECT staff_id FROM staff WHERE username = ? AND s_password = ?";
	    } else if ("Customer".equalsIgnoreCase(usertype)) {
	        sql = "SELECT 'Customer' AS usertype FROM customer WHERE username = ? AND c_password = ?";
	    }

	    // Using PreparedStatement to prevent SQL injection
	    try (Connection conn = MyDatabase.doConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {

	        // Set the parameters dynamically
	        pstmt.setString(1, user.getName());  // Set username
	        pstmt.setString(2, user.getPassword());  // Set password

	        ResultSet resultSet = pstmt.executeQuery();
	        if (resultSet.next()) {
	            if ("Staff".equalsIgnoreCase(usertype)) {
	                // Retrieve staff_id for staff user
	                staffId = resultSet.getInt("staff_id");
	            }
	        }
	        resultSet.close();
	    }

	    return staffId;
	}

    // Method to get users from the system (staff or customers)
    public ArrayList<User> getUsers(String usertype) throws ClassNotFoundException, SQLException {
        ArrayList<User> users = new ArrayList<>();
        String sql = "";

        // Determine which table to query based on usertype
        if ("Staff".equalsIgnoreCase(usertype)) {
            sql = "SELECT name, username FROM staff";
        } else if ("Customer".equalsIgnoreCase(usertype)) {
            sql = "SELECT name, username FROM customer";
        }

        // Using PreparedStatement to prevent SQL injection
        try (Connection conn = MyDatabase.doConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet resultSet = pstmt.executeQuery()) {

            while (resultSet.next()) {
                User user = new User();
                user.setName(resultSet.getString("name"));
                user.setUsername(resultSet.getString("username"));
                users.add(user);
            }
        }

        return users;
    }

    // Main method to test the functionality (can be removed or modified as needed)
    public static void main(String[] args) {
        UserController controller = new UserController();
        try {
            // Example: Fetching staff users
            ArrayList<User> staffUsers = controller.getUsers("Staff");
            for (User user : staffUsers) {
                System.out.println("Staff Name: " + user.getName());
                System.out.println("Staff Username: " + user.getUsername());
            }

            // Example: Fetching customer users
            ArrayList<User> customerUsers = controller.getUsers("Customer");
            for (User user : customerUsers) {
                System.out.println("Customer Name: " + user.getName());
                System.out.println("Customer Username: " + user.getUsername());
            }
            
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    

}
